from DiaAVPDict import DiaAVPDict
from xml.etree import ElementTree
import types

AVP_TYPE_INT="int"
AVP_TYPE_INT64="int64"
AVP_TYPE_STR="str"
AVP_TYPE_GRP="grp"

DEFAULT_AVP_INFO={'name':'Unknown', 'type':'str'}

class DiaAVP:
	def __init__(self):
		self.avpName=""
		self.avpType=""
		self.avpCode=0
		self.avpFlags=0
		self.vendor=0
		self.length=0
		self.value=0
		self.avps=[]
		
		
	def setName(self, name):
		self.avpName=name
		return True
	def getName(self):
		return self.avpName
	def setType(self, type):
		self.avpType=type
		return True
	def getType(self):
		return self.avpType
	def setCode(self, code):
		self.avpCode=code
		return True
	def getCode(self):
		return self.avpCode
	def setLength(self, len):
		self.length=len
	def getLength(self):
		return self.length
	def getLengthWithPadding(self):
		return int((self.length+4-1)/4)*4
	def setFlags(self, flags):
		self.avpFlags=flags
		return True
	def getFlags(self):
		return self.avpFlags
	def setVSFlag(self):
		self.avpFlags=self.avpFlags | 0x80
		return True
	def clearVSFlag(self):
		self.avpFlags=self.avpFlags & 0x7F
		return True
	def getVSFlag(self):
		return (self.avpFlags & 0x80)>>7
	def setMandatoryFlag(self):
		self.avpFlags=self.avpFlags | 0x40
		return True
	def clearMandatoryFlag(self):
		self.avpFlags=self.avpFlags & 0xBF
		return True
	def getMandatoryFlag(self):
		return (self.avpFlags & 0x40)>>6
	def setProtectedFlag(self):
		self.avpFlags=self.avpFlags | 0x20
		return True
	def clearProtectedFlag(self):
		self.avpFlags=self.avpFlags & 0xDF
		return True
	def getProtectedFlag(self):
		return (self.avpFlags & 0x20)>>5
	def setVendor(self, vendor):
		self.vendor=vendor
		return True
	def getVendor(self):
		return self.vendor
	def setValue(self, value):
		self.value=value
		return True
	def getValue(self):
		return self.value
		
	def getSubAVPs(self):
		return self.avps
		
	def addSubAVP(self, avp):
		if self.getType()!=AVP_TYPE_GRP:
			return False
		self.avps.append(avp)
		return True
		
#	def delSubAVP(self, avp):
#		if self.getType()!=AVP_TYPE_GRP:
#			return False
#		i=0
#		for a in self.avps:
#			if avp==a:
#				self.avps.pop(i)
#			i+=1
#		if i>=len(self.avps):
#			return False
#		return True

	def delSubAVPByAVPCode(self, code, sameAvpIndex, vendor):
		if self.getType()!=AVP_TYPE_GRP:
			return False
		i=0
		sai=0
		for a in self.avps:
			if a.getCode()==code and a.getVendor()==vendor:
				#print sai
				if sai==sameAvpIndex:
					self.avps.pop(i)
					break;
				else:
					sai+=1
			#print a.getCode(), a.getVendor()
			i+=1
		if i>=len(self.avps):
			return False
		return True
		
	def getSubAVPByAVPCode(self, code, sameAvpIndex, vendor):
		if self.getType()!=AVP_TYPE_GRP:
			return None
		i=0
		sai=0
		for a in self.avps:
			if a.getCode()==code and a.getVendor()==vendor:
				if sai==sameAvpIndex:
					return a
				else:
					sai+=1
			i+=1
		if i>=len(self.avps):
			return None
		return None
		
	def replaceSubAVPByAVPCode(self, code, sameAvpIndex, vendor, avp):
		if self.getType()!=AVP_TYPE_GRP:
			return False
		i=0
		sai=0
		for a in self.avps:
			if a.getCode()==code and a.getVendor()==vendor:
				#print sai
				if sai==sameAvpIndex:
					#print "DNB"
					#print avp.printDebugInfo()
					self.avps.pop(i)
					self.avps.insert(i, avp)
					break;
				else:
					sai+=1
			#print a.getCode(), a.getVendor()
			i+=1
		#print code, sameAvpIndex, vendor
		#print self.avpCode, self.vendor
		if i>=len(self.avps):
			return False
		return True
		
	def convert(self):
		r=""
		if self.getType()==AVP_TYPE_INT:
			r=DiaAVP.intAVP(self.avpCode,self.vendor,self.avpFlags,self.value)
		elif self.getType()==AVP_TYPE_INT64:
			r=DiaAVP.int64AVP(self.avpCode,self.vendor,self.avpFlags,self.value)
		elif self.getType()==AVP_TYPE_STR:
			r=DiaAVP.strAVP(self.avpCode,self.vendor,self.avpFlags,self.value)
		elif self.getType()==AVP_TYPE_GRP:
			v=""
			for avp in self.avps:
				v+=avp.convert()
			r=DiaAVP.strAVP(self.avpCode,self.vendor,self.avpFlags,v)
		return r
	def consolidate(self):
		l=0
		l+=4+1+3 #code, flags, len
		if self.getVendor()!=0:
			l+=4
		if self.getType()==AVP_TYPE_INT:
			l+=4
		elif self.getType()==AVP_TYPE_INT64:
			l+=8
		elif self.getType()==AVP_TYPE_STR:
			l+=len(self.getValue())
		elif self.getType()==AVP_TYPE_GRP:
			for avp in self.avps:
				avp.consolidate()
				l+=avp.getLength()
		self.setLength(l)
	
	def compareAVPValue(self, compValue):
		#print "---"
		#print compValue
		avpType=self.getType()
		if avpType==AVP_TYPE_GRP:
			#Group AVP do not support compare
			return False
		if avpType==AVP_TYPE_INT or avpType==AVP_TYPE_INT64:
			if not type(compValue) is types.IntType:
				return False
			else:
				avpValue=self.getValue()
				if avpValue==compValue:
					return True
				else:
					return False
		if avpType==AVP_TYPE_STR:
			if not type(compValue) is types.StringType:
				return False
			else:
				avpValue=self.getValue()
				#print compValue
				#print avpValue
				if not avpValue.find(compValue)==-1:
					return True
				else:
					return False
		return False
		
	def replaceAVPValue(self, avpValue):
		#This function only kept for DiaRedirector function "replace dest host and realm", this function should be disabled in the future, and use replaceSubAVPByAVPCode instead.
		#used by DiaRedirectorMM
		avpType=self.getType()
		if avpType==AVP_TYPE_GRP:
			#Group AVP do not support replace
			return False
		if avpType==AVP_TYPE_INT or avpType==AVP_TYPE_INT64:
			if not type(avpValue) is types.IntType:
				return False
			else:
				self.setValue(avpValue)
				self.consolidate()
				return True
		if avpType==AVP_TYPE_STR:
			if not type(avpValue) is types.StringType:
				return False
			else:
				self.setValue(avpValue)
				self.consolidate()
				return True
		return False		
				
		
	@classmethod
	def strAVP(cls_obj, code, vendor,flags, value):
		if vendor == 0:
			buf = "%08x%02x%06x%s" % (code,flags,len(value)+8,value.encode("hex"))
		else:
			buf = "%08x%02x%06x%08x%s" % (code,flags,len(value)+12,vendor,value.encode("hex"))
		str = ""
		i = 0
		while (i < len(buf)):
			str = str+chr(int(buf[i:i+2],16))
			i = i+2
		n = len(str)%4	
		if n == 0:
			return str
		else:
			for i in range(4-n):
				str = str+'\x00'
			return str 
	@classmethod
	def intAVP(cls_obj, code, vendor, flags, value):
		if vendor == 0:
			buf = "%08x%02x%06x%08x" % (code,flags,12,value)
		else:
			buf = "%08x%02x%06x%08x%08x" % (code,flags,16,vendor,value)
		str = ""
		i = 0
		while (i < len(buf)):
			str = str+chr(int(buf[i:i+2],16))
			i = i+2
		return str
	@classmethod
	def int64AVP(cls_obj, code, vendor, flags, value):
		if vendor == 0:
			buf = "%08x%02x%06x%16x" % (code,flags,16,value)
		else:
			buf = "%08x%02x%06x%08x%16x" % (code,flags,20,vendor,value)
		str = ""
		i = 0
		while (i < len(buf)):
			str = str+chr(int(buf[i:i+2],16))
			i = i+2
		return str
		
	def decodeAVPCode(self, avpBuff):
		if len(avpBuff)<8:
			return 0
		return int(avpBuff[0:4].encode("hex"),16)
	def decodeAVPFlags(self, avpBuff):
		if len(avpBuff)<8:
			return 0
		#print "flag:", avpBuff[4:5].encode("hex")
		return int(avpBuff[4:5].encode("hex"),16)		
	def decodeAVPLength(self, avpBuff):
		if len(avpBuff)<8:
			return 0
		return int(avpBuff[5:8].encode("hex"),16)
	def decodeAVPVendor(self, avpBuff):
		if len(avpBuff)<12:
			return 0
		return int(avpBuff[8:12].encode("hex"),16)		
	def decodeAVPIntValue(self, avpBuff, valuePos):
		if valuePos+4>len(avpBuff):
			#print "sb le"
			return 0
		return int(avpBuff[valuePos:valuePos+4].encode("hex"),16)
	def decodeAVPInt64Value(self, avpBuff, valuePos):
		if valuePos+8>len(avpBuff):
			#print "sb le"
			return 0
		return int(avpBuff[valuePos:valuePos+8].encode("hex"),16)		
	def decodeAVPStrValue(self, avpBuff, valuePos, strLen):
		return str(avpBuff[valuePos:valuePos+strLen])
		
	def decodeAVP(self, avpBuff):
		avpArray=DiaAVPDict.getAVPDict()
		pos=0
		headerLen=8
		self.setCode(self.decodeAVPCode(avpBuff))
		self.setFlags(self.decodeAVPFlags(avpBuff))
		self.setLength(self.decodeAVPLength(avpBuff))
		pos+=headerLen
		if self.getVSFlag()==True:
			self.setVendor(self.decodeAVPVendor(avpBuff))
			pos+=4
			headerLen+=4
		else:
			self.setVendor(0)
		avpFoundFlag=False
		if avpArray.has_key(self.getVendor()):
			vendorAVPArray=avpArray[self.getVendor()]
			if vendorAVPArray.has_key(self.getCode()):
				avpFoundFlag=True
		if avpFoundFlag==True:
			avpInfo=vendorAVPArray[self.getCode()]
		else:
			avpInfo=DEFAULT_AVP_INFO
		self.setName(avpInfo['name'])
		self.setType(avpInfo['type'])
		if avpInfo['type']==AVP_TYPE_INT:
			self.setValue(self.decodeAVPIntValue(avpBuff,pos))
			pos+=4
		elif avpInfo['type']==AVP_TYPE_INT64:
			self.setValue(self.decodeAVPInt64Value(avpBuff,pos))
			pos+=8		
		elif avpInfo['type']==AVP_TYPE_STR:
			self.setValue(self.decodeAVPStrValue(avpBuff,pos,self.getLength()-headerLen))
			pos+=self.getLength()-headerLen
		elif avpInfo['type']==AVP_TYPE_GRP:
			self.setValue("")
			while pos<len(avpBuff):
				subAVP=DiaAVP()
				subAVP.decodeAVP(avpBuff[pos:])
				pos+=subAVP.getLengthWithPadding()
				self.addSubAVP(subAVP)
				if pos>=self.getLength():
					break
		self.consolidate()
		return pos
		
	@classmethod
	def readAVPFromXmlRoot(cls_obj, avpRoot):
		avpArray=DiaAVPDict.getAVPDict()
		avpName=avpRoot.attrib["name"]
		#avpType=avpRoot.attrib["type"]
		avpCode=int(avpRoot.attrib["code"])
		avpVendor=int(avpRoot.attrib["vendor"])
		avpFlags=int(avpRoot.attrib["flags"])
		if avpRoot.attrib.has_key("type"):
			avpType=avpRoot.attrib["type"]
		else:
			avpFoundFlag=False
			if avpArray.has_key(avpVendor):
				vendorAVPArray=avpArray[avpVendor]
				if vendorAVPArray.has_key(avpCode):
					avpFoundFlag=True
			#print vendorAVPArray
			if avpFoundFlag==True:
				avpType=vendorAVPArray[avpCode]['type']
			else:
				avpType=DEFAULT_AVP_INFO['type']	
		#print avpName
		#print avpCode
		#print avpType
		#print avpFoundFlag
		avp=DiaAVP()
		avp.setName(avpName)
		avp.setType(avpType)
		avp.setCode(avpCode)
		avp.setVendor(avpVendor)
		avp.setFlags(avpFlags)
		#print avp.getName()
		if avpType==AVP_TYPE_INT or avpType==AVP_TYPE_INT64:
			avpValue=int(avpRoot.text)
			avp.setValue(avpValue)
			avp.consolidate()
			return avp
		elif avpType==AVP_TYPE_STR:
			avpValue=avpRoot.text
			#print "avpName",avpName
			#print "avpValue",len(avpValue)
			avpValue=cls_obj.formatAVPString2(avpValue)
			avp.setValue(avpValue)
			avp.consolidate()
			return avp
		elif avpType==AVP_TYPE_GRP:
			subAVPRoots=avpRoot.findall("AVP")
			if len(subAVPRoots)!=0:
				for subAVPRoot in subAVPRoots:
					avp.addSubAVP(cls_obj.readAVPFromXmlRoot(subAVPRoot))
				avp.consolidate()
				return avp
		return None
		
	@classmethod	
	def formatAVPString(cls_obj, avpString):
		i=0
		r=""
		while i<len(avpString):
			c=avpString[i:i+2]
			v=avpString[i+2:i+4]
			#print c
			if c!="\\x":
				return avpString
				#Malform avpString, return original string.
			else:
				try:
					r+=chr(int(v,16))
				except Exception as e:
					print "    Malform hex string, it should be like \\x0c\\x0d, not \\xc\\x0d or \\xc\\xd"
					raise e
			i+=4
		return r
		
	@classmethod	
	def formatAVPString2(cls_obj, avpString):
		s=0
		p=0
		r=""
		while p<len(avpString):
			p=avpString[s:].find("\\x")
			#print avpString[s:]
			#print p
			if p!=-1:
				v=avpString[s+p+2:s+p+4]
				#print "v", v
				r+=avpString[s:s+p]
				r+=chr(int(v,16))
				s=s+p+4
			else:
				r+=avpString[s:]
				break
		return r
	
	def printDebugTab(self, tab):
		i=0
		while i<tab:
			print " ",
			i+=1
		
	def printDebugInfo(self, tab=0): 
		self.printDebugTab(tab)
		print "name",self.avpName
		self.printDebugTab(tab)
		print "type",self.avpType
		self.printDebugTab(tab)
		print "code",self.avpCode
		self.printDebugTab(tab)
		print "flags",self.avpFlags
		self.printDebugTab(tab)		
		print "vendor",self.vendor
		self.printDebugTab(tab)
		print "length",self.length
		#self.printDebugTab(tab)
		#print self.value
		if self.getType()==AVP_TYPE_STR:
			#print len(self.value)
			#print self.value.encode("hex")
			v=self.value.replace('\x0d','')
			v=v.replace('\x0a','')
		else:
			v=str(self.value)
		self.printDebugTab(tab)
		print "|",v,"|"
		#print len(self.avps)
		#print self.convert().encode("hex")
		print "--------------------------------"
		for avp in self.avps:
			#pass
			#print "!!!!"
			#print "sub:", len(self.avps)
			#print "####"
			avp.printDebugInfo(tab+4)

#main
def main():
	buff1="\x00\x00\x01\x08\x40\x00\x00\x3b\x70\x63\x73\x63\x66\x31\x2e\x66\x7a\x2e\x66\x6a\x2e\x6e\x6f\x64\x65\x2e\x65\x70\x63\x2e\x6d\x6e\x63\x30\x30\x30\x2e\x6d\x63\x63\x34\x36\x30\x2e\x33\x67\x70\x70\x6e\x65\x74\x77\x6f\x72\x6b\x2e\x6f\x72\x67\x00"

	buff2="\x00\x00\x02\x01\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01"

	buff3="\x00\x00\x02\x05\xc0\x00\x03\x84\x00\x00\x28\xaf\x00\x00\x02\x0c\xc0\x00\x01\x5f\x00\x00\x28\xaf\x64\x6f\x77\x6e\x6c\x69\x6e\x6b\x0a\x6f\x66\x66\x65\x72\x0a\x6d\x3d\x61\x75\x64\x69\x6f\x20\x35\x30\x30\x31\x30\x20\x52\x54\x50\x2f\x41\x56\x50\x20\x31\x30\x34\x20\x31\x30\x32\x20\x31\x30\x35\x20\x31\x30\x30\x0d\x0a\x61\x3d\x72\x74\x70\x6d\x61\x70\x3a\x31\x30\x34\x20\x41\x4d\x52\x2d\x57\x42\x2f\x31\x36\x30\x30\x30\x2f\x31\x0d\x0a\x61\x3d\x66\x6d\x74\x70\x3a\x31\x30\x34\x20\x6d\x6f\x64\x65\x2d\x63\x68\x61\x6e\x67\x65\x2d\x63\x61\x70\x61\x62\x69\x6c\x69\x74\x79\x3d\x32\x3b\x6d\x61\x78\x2d\x72\x65\x64\x3d\x30\x0d\x0a\x61\x3d\x72\x74\x70\x6d\x61\x70\x3a\x31\x30\x32\x20\x41\x4d\x52\x2f\x38\x30\x30\x30\x2f\x31\x0d\x0a\x61\x3d\x66\x6d\x74\x70\x3a\x31\x30\x32\x20\x6d\x6f\x64\x65\x2d\x63\x68\x61\x6e\x67\x65\x2d\x63\x61\x70\x61\x62\x69\x6c\x69\x74\x79\x3d\x32\x3b\x6d\x61\x78\x2d\x72\x65\x64\x3d\x30\x0d\x0a\x61\x3d\x72\x74\x70\x6d\x61\x70\x3a\x31\x30\x35\x20\x74\x65\x6c\x65\x70\x68\x6f\x6e\x65\x2d\x65\x76\x65\x6e\x74\x2f\x31\x36\x30\x30\x30\x2f\x31\x0d\x0a\x61\x3d\x66\x6d\x74\x70\x3a\x31\x30\x35\x20\x30\x2d\x31\x35\x0d\x0a\x61\x3d\x72\x74\x70\x6d\x61\x70\x3a\x31\x30\x30\x20\x74\x65\x6c\x65\x70\x68\x6f\x6e\x65\x2d\x65\x76\x65\x6e\x74\x2f\x38\x30\x30\x30\x2f\x31\x0d\x0a\x61\x3d\x66\x6d\x74\x70\x3a\x31\x30\x30\x20\x30\x2d\x31\x35\x0d\x0a\x61\x3d\x6d\x61\x78\x70\x74\x69\x6d\x65\x3a\x32\x34\x30\x0d\x0a\x61\x3d\x70\x74\x69\x6d\x65\x3a\x32\x30\x0d\x0a\x00\x00\x00\x01\xff\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x03\x00\x00\x02\x06\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x07\xc0\x00\x00\xec\x00\x00\x28\xaf\x00\x00\x01\xfb\xc0\x00\x00\x6b\x00\x00\x28\xaf\x70\x65\x72\x6d\x69\x74\x20\x6f\x75\x74\x20\x31\x37\x20\x66\x72\x6f\x6d\x20\x32\x30\x30\x30\x3a\x43\x30\x41\x38\x3a\x41\x35\x36\x30\x3a\x32\x38\x30\x30\x3a\x3a\x36\x39\x2f\x31\x32\x38\x20\x74\x6f\x20\x32\x30\x30\x30\x3a\x61\x63\x31\x32\x3a\x38\x34\x30\x30\x3a\x31\x63\x35\x65\x3a\x63\x35\x31\x34\x3a\x39\x65\x34\x61\x3a\x35\x65\x37\x33\x3a\x63\x36\x39\x34\x20\x35\x30\x30\x31\x30\x00\x00\x00\x01\xfb\xc0\x00\x00\x64\x00\x00\x28\xaf\x70\x65\x72\x6d\x69\x74\x20\x69\x6e\x20\x31\x37\x20\x66\x72\x6f\x6d\x20\x32\x30\x30\x30\x3a\x61\x63\x31\x32\x3a\x38\x34\x30\x30\x3a\x31\x63\x35\x65\x3a\x63\x35\x31\x34\x3a\x39\x65\x34\x61\x3a\x35\x65\x37\x33\x3a\x63\x36\x39\x34\x20\x74\x6f\x20\x32\x30\x30\x30\x3a\x43\x30\x41\x38\x3a\x41\x35\x36\x30\x3a\x32\x38\x30\x30\x3a\x3a\x36\x39\x2f\x31\x32\x38\x00\x00\x01\xfd\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x07\xc0\x00\x00\xfc\x00\x00\x28\xaf\x00\x00\x01\xfb\xc0\x00\x00\x6b\x00\x00\x28\xaf\x70\x65\x72\x6d\x69\x74\x20\x6f\x75\x74\x20\x31\x37\x20\x66\x72\x6f\x6d\x20\x32\x30\x30\x30\x3a\x43\x30\x41\x38\x3a\x41\x35\x36\x30\x3a\x32\x38\x30\x30\x3a\x3a\x36\x39\x2f\x31\x32\x38\x20\x74\x6f\x20\x32\x30\x30\x30\x3a\x61\x63\x31\x32\x3a\x38\x34\x30\x30\x3a\x31\x63\x35\x65\x3a\x63\x35\x31\x34\x3a\x39\x65\x34\x61\x3a\x35\x65\x37\x33\x3a\x63\x36\x39\x34\x20\x35\x30\x30\x31\x31\x00\x00\x00\x01\xfb\xc0\x00\x00\x64\x00\x00\x28\xaf\x70\x65\x72\x6d\x69\x74\x20\x69\x6e\x20\x31\x37\x20\x66\x72\x6f\x6d\x20\x32\x30\x30\x30\x3a\x61\x63\x31\x32\x3a\x38\x34\x30\x30\x3a\x31\x63\x35\x65\x3a\x63\x35\x31\x34\x3a\x39\x65\x34\x61\x3a\x35\x65\x37\x33\x3a\x63\x36\x39\x34\x20\x74\x6f\x20\x32\x30\x30\x30\x3a\x43\x30\x41\x38\x3a\x41\x35\x36\x30\x3a\x32\x38\x30\x30\x3a\x3a\x36\x39\x2f\x31\x32\x38\x00\x00\x01\xfd\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x02\x00\x00\x02\x00\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x08\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x00"

	buff4="\x00\x00\x02\x74\x80\x00\x00\x38\x00\x00\x28\xaf\x00\x00\x01\x0a\x40\x00\x00\x0c\x00\x00\x28\xaf\x00\x00\x02\x75\x80\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x76\x80\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x05"
	#avp=DiaAVP()
	#avp.decodeAVP(buff3)
	#avp.printDebugInfo()
	s="a"
	print s
	r=DiaAVP.formatAVPString2(s)
	print r
if __name__ == '__main__':
	pass
	#main()
