import os, re
from random import randint, random
from xml.etree import ElementTree
from DiaAVP import *
from DiaFragmentor import DiaFragmentor

DIA_MSG_HDR_LEN=20

MCDPR_FAKE_GROUP=4294967295
MCDPR_FAKE_GROUP_CODE_1=1
MCDPR_FAKE_GROUP_CODE_1_NAME="RootAVPPtr"

class DiaAVPPath:
	def __init__(self):
		self.origPath=""
		self.pathArray=[]
		
	def analyzePath(self, path):
		seperator="->"
		nodes=[]
		s=0
		while True:
			e=path.find(seperator,s)
			if e==-1:
				break
			else:
				#print s, e
				if not s==e:
					nodes.append(path[s:e])
					s=e+len(seperator)
				else:
					break;
		if e==-1:
			nodes.append(path[s:])
		#print nodes
		return nodes
		
	def analyzeNode(self, node):
		vendor=int(node[:node.find("/")])
		code=int(node[node.find("/")+1:node.find("[")])
		sai=int(node[node.find("[")+1:node.find("]")])
		r=[vendor, code, sai]
		return r
		
	def analyzePathNodes(self, nodes):
		for node in nodes:
			s=re.match("\d+/\d+\[\d+]$", node)
			if not s==None:
				avpData=self.analyzeNode(node)
				self.pathArray.append(avpData)
			else:
				break;
		
	def setPath(self, path):
	#path should be like: 10415/624[0]->10415/425[1] , vendor/code[sai]
		self.origPath=path
		nodes=self.analyzePath(path)
		self.analyzePathNodes(nodes)
		#print self.pathArray
	
	def getPath(self):
		return self.origPath
		
	def getLayerNumber(self):
		return len(self.pathArray)
		
	def getAVPVendor(self, layer):
		return self.pathArray[layer][0]
		
	def getAVPCode(self, layer):
		return self.pathArray[layer][1]
	
	def getAVPSAI(self, layer):
		return self.pathArray[layer][2]
		
	def getSubPath(self, layer):
		#10415/624[0]->10415/425[1]
		i=0
		s=""
		if layer>=self.getLayerNumber():
			return ""
		while i<=layer:
			if not i==layer:
				s+=str(self.getAVPVendor(i))+"/"+str(self.getAVPCode(i))+"["+str(self.getAVPSAI(i))+"]"+"->"
			else:
				s+=str(self.getAVPVendor(i))+"/"+str(self.getAVPCode(i))+"["+str(self.getAVPSAI(i))+"]"
			i+=1
		return s
		
		
class DiaMessage():
	def __init__(self):
		self.name=""
		self.version=1
		self.length=0
		self.cmdcode=0
		self.flags=0
		self.requestFlag=0
		self.proxyableFlag=0
		self.errorBit=0
		self.TBit=0
		self.length=0
		self.appid=0
		self.ebeid=0
		self.hbhid=0
		#self.avps=[]
		self.rootAVP=DiaAVP()
		self.rootAVP.setVendor(MCDPR_FAKE_GROUP)
		self.rootAVP.setName(MCDPR_FAKE_GROUP_CODE_1_NAME)
		self.rootAVP.setType(AVP_TYPE_GRP)
		self.rootAVP.setCode(MCDPR_FAKE_GROUP_CODE_1)
		

	#here define some functions to support add, delete, replace AVP in path style, this will help operate the AVP in group AVP.
	def addAVPByPath(self, dap, avp):
		#dap is a DiaAVPPath object.
		#path should be like: 10415/624[0]->10415/425[1]
		layerNo=dap.getLayerNumber()
		if layerNo==0:
			rootAVP=self.rootAVP
		else:
			rootAVP=self.getAVPByPath(dap)
		if not rootAVP==None:
			#print "NB"
			return rootAVP.addSubAVP(avp)
		return False	
	
	def removeAVPByPath(self, dap):
		#dap is a DiaAVPPath object.
		#path should be like: 10415/624[0]->10415/425[1]
		layerNo=dap.getLayerNumber()
		if layerNo==0:
			return;
		rootDAP=DiaAVPPath()
		rootDAP.setPath(dap.getSubPath(layerNo-2))
		rootAVP=self.getAVPByPath(rootDAP)
		if not rootAVP==None:
			#print "NB"
			return rootAVP.delSubAVPByAVPCode(dap.getAVPCode(layerNo-1),dap.getAVPSAI(layerNo-1),dap.getAVPVendor(layerNo-1))
		return False
		
		
	def replaceAVPByPath(self, dap, avp):
		#dap is a DiaAVPPath object.
		#print dap
		layerNo=dap.getLayerNumber()
		if layerNo==0:
			return;
		rootDAP=DiaAVPPath()
		rootDAP.setPath(dap.getSubPath(layerNo-2))
		#print "layerNo-2", dap.getSubPath(layerNo-2)==""
		#print rootDAP.getLayerNumber()
		rootAVP=self.getAVPByPath(rootDAP)
		#print rootAVP
		if not rootAVP==None:
			#print "NB"
			return rootAVP.replaceSubAVPByAVPCode(dap.getAVPCode(layerNo-1),dap.getAVPSAI(layerNo-1),dap.getAVPVendor(layerNo-1), avp)
		return False
				
	def getAVPByPath(self, dap):
		layerNo=dap.getLayerNumber()
		if layerNo==0:
			return self.rootAVP;
		rootAVP=self.rootAVP
		i=0
		while i<layerNo:
			#print rootAVP
			if not rootAVP==None:
				rootAVP=rootAVP.getSubAVPByAVPCode(dap.getAVPCode(i),dap.getAVPSAI(i),dap.getAVPVendor(i))
			i+=1
		if not rootAVP==None:
			return rootAVP
		
	def setLength(self, length):
		self.length=length
	def getLength(self):
		return self.length
	def getEBEID(self):
		return self.ebeid
	def setEBEID(self,ebeid):
		self.ebeid=ebeid
	def getHBHID(self):
		return self.hbhid
	def setHBHID(self,hbhid):
		self.hbhid=hbhid	
	def setFlags(self, flags):
		self.flags=flags
	def getFlags(self):
		return self.flags
	def setRequestFlag(self):
		self.flags=self.flags | 0x80
	def clearRequestFlag(self):
		self.flags=self.flags & 0x7F
	def getRequestFlag(self):
		return (self.flags & 0x80)>>7
	def setProxyableFlag(self):
		self.flags=self.flags | 0x40
	def clearProxyableFlag(self):
		self.flags=self.flags & 0xBF
	def getProxyableFlag(self):
		return (self.flags & 0x40)>>6
	def setEBitFlag(self):
		self.flags=self.flags | 0x20
	def clearEBitFlag(self):
		self.flags=self.flags & 0xDF
	def getEBitFlag(self):
		return (self.flags & 0x20)>>5
	def setTBitFlag(self):
		self.flags=self.flags | 0x10
	def clearTBitFlag(self):
		self.flags=self.flags & 0xEF
	def getTBitFlag(self):
		return (self.flags & 0x10)>>4
	def setCommandCode(self, cmdcode):
		self.cmdcode=cmdcode
	def getCommandCode(self):
		return self.cmdcode
	def setApplicationId(self, appid):
		self.appid=appid
	def getApplicationId(self):
		return self.appid
	def generateRandomHBHID(self):
		self.setHBHID(randint(0,0xffffffff))
	def generateRandomEBEID(self):
		self.setEBEID(randint(0,0xffffffff))
	def decodeMessage(self, msgBuff):
		self.version=int(msgBuff[0].encode("hex"),16)
		self.length=int(msgBuff[1:4].encode("hex"),16)
		self.setFlags(int(msgBuff[4].encode("hex"),16))
		self.setCommandCode(int(msgBuff[5:8].encode("hex"),16))
		self.setApplicationId(int(msgBuff[8:12].encode("hex"),16))
		self.setHBHID(int(msgBuff[12:16].encode("hex"),16))
		self.setEBEID(int(msgBuff[16:20].encode("hex"),16))
		headerLen=20
		buff=msgBuff[headerLen:]
		pos=headerLen
		while pos<len(msgBuff):
			avp=DiaAVP()
			avp.decodeAVP(msgBuff[pos:])
			#avp.printDebugInfo(4)
			self.rootAVP.addSubAVP(avp)
			pos+=avp.getLengthWithPadding()
			#print pos
		self.consolidate()
	def convert(self):
		l=0
		avpStr=""
		for avp in self.rootAVP.getSubAVPs():
			#print avp.getName()
			#print avp.getType()
			avpStr+=avp.convert()
		l=DIA_MSG_HDR_LEN+len(avpStr)
		hd="%02x%06x%02x%06x%08x%08x%08x" %(self.version, l, self.getFlags(), self.getCommandCode(), self.getApplicationId(), self.getHBHID(), self.getEBEID())
		self.setLength(l)
		hdStr = ""
		i = 0
		while (i < len(hd)):
			hdStr = hdStr+chr(int(hd[i:i+2],16))
			i = i+2
		r=hdStr+avpStr
		return r
		
	def consolidate(self):
		self.convert()
		
	def printDebugInfo(self):
		print "version",self.version
		print "Length", self.length
		print "Flags", self.getRequestFlag(), self.getProxyableFlag(),self.getEBitFlag(), self.getTBitFlag()
		print "CommandCode", self.getCommandCode()
		print "AppID", self.getApplicationId()
		print "HBHID", self.getHBHID()
		print "EBEID", self.getEBEID()
		for avp in self.rootAVP.getSubAVPs():
			avp.printDebugInfo()
			
	def isRequest(self):
		if self.getRequestFlag()==1:
			return True
		else:
			return False
		
	def getInfo(self):
		if self.getCommandCode()!=0:
			return "CommandCode: "+str(self.getCommandCode())
		return ""
		
	def getName(self):
		return self.name
		
	def setName(self, name):
		self.name=name
		
class DiaMessageReader():	

	def formatFlags(self, bit0, bit1, bit2, bit3, bit4, bit5, bit6, bit7):
		bits=[bit0, bit1, bit2, bit3, bit4, bit5, bit6, bit7]
		i=7
		v=0 & 0x00
		while i>0:
			b=bits[i]
			v=v|b
			v<<=1
			#print v
			i-=1
		return v

	def createNullMessage(self, msgName):
		msg=DiaMessage()
		msg.setName(msgName)
		return msg
		
	def createMessageFromXMLFile(self, filename):
		if not os.path.exists(filename):
			print "    Can't find file", filename
			return None
		try:
		#print "try"
			doc=ElementTree.parse(filename)
			root=doc.getroot()
			commandRoot=root.find("CommandCode")
			commandCode=int(commandRoot.text)
			appidRoot=root.find("Application-Id")
			appid=int(appidRoot.text)
			requestRoot=root.find("Request")
			proxyableRoot=root.find("Proxyable")
			errorBitRoot=root.find("ErrorBit")
			TBitRoot=root.find("TBit")
			if requestRoot==None:
				print "    Request flag is needed(True/False) in XML file for message creation."
			isRequest=requestRoot.text.upper()
			if proxyableRoot==None:
				proxyable=1
			else:
				proxyable=int(proxyableRoot.text)
			if errorBitRoot==None:
				errorBit=0
			else:
				errorBit=int(errorBitRoot.text)
			if TBitRoot==None:
				TBit=0
			else:
				TBit=int(TBitRoot)
			msg=DiaMessage()
			msg.setCommandCode(commandCode)
			msg.setApplicationId(appid)
			if isRequest=="TRUE":
				flags=self.formatFlags(0,0,0,0,TBit,errorBit,proxyable,1)
			else:
				flags=self.formatFlags(0,0,0,0,TBit,errorBit,proxyable,0)
			#print "flags:", flags
			msg.setFlags(flags)
			msg.generateRandomEBEID()
			msg.generateRandomHBHID()
			avps=root.findall("AVP")
			#print "avps"
			nullDap=DiaAVPPath()
			for avpRoot in avps:
				#print avpRoot.attrib["name"]
				avp=DiaAVP.readAVPFromXmlRoot(avpRoot)
				if avp!=None:
					#print "###"
					#avp.printDebugInfo()
					#print "!!!"
					
					msg.addAVPByPath(nullDap,avp)
				#print "abc"
		except Exception as e:
			print "   ", e
			return None
		msg.consolidate()
		return msg
		
#main
#dmr=DiaMessageReader()
#dm=dmr.createMessageFromXMLFile("cer.xml")
#print dm.printDebugInfo()
#buff1="\x01\x00\x05\xe4\xc0\x00\x01\x09\x01\x00\x00\x14\x6d\xa0\x00\x04\x6d\xa0\x00\x04\x00\x00\x01\x07\x40\x00\x00\x70\x70\x63\x73\x63\x66\x31\x2e\x33\x67\x70\x70\x6e\x65\x74\x77\x6f\x72\x6b\x2e\x6f\x72\x67\x3b\x30\x3b\x30\x3b\x31\x33\x36\x66\x34\x62\x39\x35\x33\x38\x38\x61\x62\x36\x62\x37\x31\x36\x36\x38\x61\x62\x66\x65\x61\x63\x30\x66\x61\x65\x31\x61\x5e\x34\x66\x64\x66\x66\x39\x31\x37\x31\x39\x64\x61\x62\x62\x31\x36\x39\x38\x31\x33\x61\x63\x33\x38\x39\x34\x39\x35\x63\x61\x37\x64\x5e\x50\x4f\x38\x5e\x46\x50\x5f\x50\x43\x52\x46\x00\x00\x01\x02\x40\x00\x00\x0c\x01\x00\x00\x14\x00\x00\x01\x08\x40\x00\x00\x3b\x70\x63\x73\x63\x66\x31\x2e\x66\x7a\x2e\x66\x6a\x2e\x6e\x6f\x64\x65\x2e\x65\x70\x63\x2e\x6d\x6e\x63\x30\x30\x30\x2e\x6d\x63\x63\x34\x36\x30\x2e\x33\x67\x70\x70\x6e\x65\x74\x77\x6f\x72\x6b\x2e\x6f\x72\x67\x00\x00\x00\x01\x28\x40\x00\x00\x25\x6d\x6e\x63\x30\x30\x30\x2e\x6d\x63\x63\x34\x36\x30\x2e\x33\x67\x70\x70\x6e\x65\x74\x77\x6f\x72\x6b\x2e\x6f\x72\x67\x00\x00\x00\x00\x00\x01\x1b\x40\x00\x00\x25\x6d\x6e\x63\x30\x30\x30\x2e\x6d\x63\x63\x34\x36\x30\x2e\x33\x67\x70\x70\x6e\x65\x74\x77\x6f\x72\x6b\x2e\x6f\x72\x67\x00\x00\x00\x00\x00\x01\xf8\xc0\x00\x00\x31\x00\x00\x28\xaf\x75\x72\x6e\x3a\x75\x72\x6e\x2d\x37\x3a\x33\x67\x70\x70\x2d\x73\x65\x72\x76\x69\x63\x65\x2e\x69\x6d\x73\x2e\x69\x63\x73\x69\x2e\x6d\x6d\x74\x65\x6c\x00\x00\x00\x00\x00\x01\xf9\xc0\x00\x00\x2c\x00\x00\x28\xaf\x64\x33\x35\x66\x34\x32\x37\x38\x64\x39\x38\x61\x32\x36\x30\x62\x31\x30\x61\x63\x30\x34\x32\x35\x65\x32\x65\x64\x65\x66\x31\x35\x00\x00\x00\x61\x40\x00\x00\x1a\x00\x80\x20\x00\xac\x12\x84\x00\x1c\x5e\xc5\x14\x9e\x4a\x5e\x73\xc6\x94\x00\x00\x00\x00\x02\x05\xc0\x00\x03\x84\x00\x00\x28\xaf\x00\x00\x02\x0c\xc0\x00\x01\x5f\x00\x00\x28\xaf\x64\x6f\x77\x6e\x6c\x69\x6e\x6b\x0a\x6f\x66\x66\x65\x72\x0a\x6d\x3d\x61\x75\x64\x69\x6f\x20\x35\x30\x30\x31\x30\x20\x52\x54\x50\x2f\x41\x56\x50\x20\x31\x30\x34\x20\x31\x30\x32\x20\x31\x30\x35\x20\x31\x30\x30\x0d\x0a\x61\x3d\x72\x74\x70\x6d\x61\x70\x3a\x31\x30\x34\x20\x41\x4d\x52\x2d\x57\x42\x2f\x31\x36\x30\x30\x30\x2f\x31\x0d\x0a\x61\x3d\x66\x6d\x74\x70\x3a\x31\x30\x34\x20\x6d\x6f\x64\x65\x2d\x63\x68\x61\x6e\x67\x65\x2d\x63\x61\x70\x61\x62\x69\x6c\x69\x74\x79\x3d\x32\x3b\x6d\x61\x78\x2d\x72\x65\x64\x3d\x30\x0d\x0a\x61\x3d\x72\x74\x70\x6d\x61\x70\x3a\x31\x30\x32\x20\x41\x4d\x52\x2f\x38\x30\x30\x30\x2f\x31\x0d\x0a\x61\x3d\x66\x6d\x74\x70\x3a\x31\x30\x32\x20\x6d\x6f\x64\x65\x2d\x63\x68\x61\x6e\x67\x65\x2d\x63\x61\x70\x61\x62\x69\x6c\x69\x74\x79\x3d\x32\x3b\x6d\x61\x78\x2d\x72\x65\x64\x3d\x30\x0d\x0a\x61\x3d\x72\x74\x70\x6d\x61\x70\x3a\x31\x30\x35\x20\x74\x65\x6c\x65\x70\x68\x6f\x6e\x65\x2d\x65\x76\x65\x6e\x74\x2f\x31\x36\x30\x30\x30\x2f\x31\x0d\x0a\x61\x3d\x66\x6d\x74\x70\x3a\x31\x30\x35\x20\x30\x2d\x31\x35\x0d\x0a\x61\x3d\x72\x74\x70\x6d\x61\x70\x3a\x31\x30\x30\x20\x74\x65\x6c\x65\x70\x68\x6f\x6e\x65\x2d\x65\x76\x65\x6e\x74\x2f\x38\x30\x30\x30\x2f\x31\x0d\x0a\x61\x3d\x66\x6d\x74\x70\x3a\x31\x30\x30\x20\x30\x2d\x31\x35\x0d\x0a\x61\x3d\x6d\x61\x78\x70\x74\x69\x6d\x65\x3a\x32\x34\x30\x0d\x0a\x61\x3d\x70\x74\x69\x6d\x65\x3a\x32\x30\x0d\x0a\x00\x00\x00\x01\xff\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x03\x00\x00\x02\x06\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x07\xc0\x00\x00\xec\x00\x00\x28\xaf\x00\x00\x01\xfb\xc0\x00\x00\x6b\x00\x00\x28\xaf\x70\x65\x72\x6d\x69\x74\x20\x6f\x75\x74\x20\x31\x37\x20\x66\x72\x6f\x6d\x20\x32\x30\x30\x30\x3a\x43\x30\x41\x38\x3a\x41\x35\x36\x30\x3a\x32\x38\x30\x30\x3a\x3a\x36\x39\x2f\x31\x32\x38\x20\x74\x6f\x20\x32\x30\x30\x30\x3a\x61\x63\x31\x32\x3a\x38\x34\x30\x30\x3a\x31\x63\x35\x65\x3a\x63\x35\x31\x34\x3a\x39\x65\x34\x61\x3a\x35\x65\x37\x33\x3a\x63\x36\x39\x34\x20\x35\x30\x30\x31\x30\x00\x00\x00\x01\xfb\xc0\x00\x00\x64\x00\x00\x28\xaf\x70\x65\x72\x6d\x69\x74\x20\x69\x6e\x20\x31\x37\x20\x66\x72\x6f\x6d\x20\x32\x30\x30\x30\x3a\x61\x63\x31\x32\x3a\x38\x34\x30\x30\x3a\x31\x63\x35\x65\x3a\x63\x35\x31\x34\x3a\x39\x65\x34\x61\x3a\x35\x65\x37\x33\x3a\x63\x36\x39\x34\x20\x74\x6f\x20\x32\x30\x30\x30\x3a\x43\x30\x41\x38\x3a\x41\x35\x36\x30\x3a\x32\x38\x30\x30\x3a\x3a\x36\x39\x2f\x31\x32\x38\x00\x00\x01\xfd\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x07\xc0\x00\x00\xfc\x00\x00\x28\xaf\x00\x00\x01\xfb\xc0\x00\x00\x6b\x00\x00\x28\xaf\x70\x65\x72\x6d\x69\x74\x20\x6f\x75\x74\x20\x31\x37\x20\x66\x72\x6f\x6d\x20\x32\x30\x30\x30\x3a\x43\x30\x41\x38\x3a\x41\x35\x36\x30\x3a\x32\x38\x30\x30\x3a\x3a\x36\x39\x2f\x31\x32\x38\x20\x74\x6f\x20\x32\x30\x30\x30\x3a\x61\x63\x31\x32\x3a\x38\x34\x30\x30\x3a\x31\x63\x35\x65\x3a\x63\x35\x31\x34\x3a\x39\x65\x34\x61\x3a\x35\x65\x37\x33\x3a\x63\x36\x39\x34\x20\x35\x30\x30\x31\x31\x00\x00\x00\x01\xfb\xc0\x00\x00\x64\x00\x00\x28\xaf\x70\x65\x72\x6d\x69\x74\x20\x69\x6e\x20\x31\x37\x20\x66\x72\x6f\x6d\x20\x32\x30\x30\x30\x3a\x61\x63\x31\x32\x3a\x38\x34\x30\x30\x3a\x31\x63\x35\x65\x3a\x63\x35\x31\x34\x3a\x39\x65\x34\x61\x3a\x35\x65\x37\x33\x3a\x63\x36\x39\x34\x20\x74\x6f\x20\x32\x30\x30\x30\x3a\x43\x30\x41\x38\x3a\x41\x35\x36\x30\x3a\x32\x38\x30\x30\x3a\x3a\x36\x39\x2f\x31\x32\x38\x00\x00\x01\xfd\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x02\x00\x00\x02\x00\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x08\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x00\x00\x00\x02\x0f\x80\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x01\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x01\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x02\x00\x00\x02\x01\xc0\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x04\x00\x00\x01\xbb\x40\x00\x00\x50\x00\x00\x01\xbc\x40\x00\x00\x3c\x73\x69\x70\x3a\x2b\x38\x36\x31\x33\x34\x30\x30\x30\x33\x30\x30\x36\x38\x40\x69\x6d\x73\x2e\x6d\x6e\x63\x30\x30\x38\x2e\x6d\x63\x63\x34\x36\x30\x2e\x33\x67\x70\x70\x6e\x65\x74\x77\x6f\x72\x6b\x2e\x6f\x72\x67\x00\x00\x01\xc2\x40\x00\x00\x0c\x00\x00\x00\x02\x00\x00\x02\x74\xc0\x00\x00\x38\x00\x00\x28\xaf\x00\x00\x02\x76\x80\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x75\x80\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x01\x0a\x40\x00\x00\x0c\x00\x00\x28\xaf"


#avpBuff1="\x00\x00\x02\x74\x80\x00\x00\x38\x00\x00\x28\xaf\x00\x00\x01\x0a\x40\x00\x00\x0c\x00\x00\x28\xaf\x00\x00\x02\x75\x80\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x01\x00\x00\x02\x76\x80\x00\x00\x10\x00\x00\x28\xaf\x00\x00\x00\x05"
#dap=DiaAVPPath()
#dap.setPath("10415/517[0]->10415/519[1]->10415/507[0]")
#print dap.getSubPath(2)
#dap2=DiaAVPPath()
#dap2.setPath("10415/517[0]")

#a->10415/517[0]->10415/519[1]->10415/507[0]->

#dm=DiaMessage()
#dm.decodeMessage(buff1)
#path0=""
#path1="10415/517[0]"
#path2="10415/517[0]->10415/519[0]"
#path3="10415/517[0]->10415/519[0]->10415/507[0]"
#path4="10415/628[0]"
#avp1=DiaAVP()
#avp1.decodeAVP(avpBuff1)
#avp1.printDebugInfo()
#dm.addAVPByPath(path3,avp1)
#dap=DiaAVPPath()
#dap.setPath(path2)
#print dm.removeAVPByPath(dap)
#dm.getAVPByPath(path3).printDebugInfo()
#dm.replaceAVPByPath(path3,avp1)
#print dm.addAVPByPath(path2,avp1)
#print dm.removeAVPByPath(path2)

#dm2=DiaMessage()
#dm2.decodeMessage(buff1)

####################
#import socket
#Lport = 3868
#Rport = 3868
#host = "172.18.6.158"
#remote="172.18.6.1"
#s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
#print s
#s.bind((host,Lport))
#s.sendto(dm.convert(),(remote,Rport))
#s.sendto(dm2.convert(),(remote,Rport))
#exit()
#dmr=DiaMessageReader()
#dm1=dmr.createMessageFromXMLFile("cer.xml")
#dm1.printDebugInfo()
#buff2=dm1.convert()
#print "========================================"
#dm1.printDebugInfo()
#dm2=DiaMessage()
#dm2.decodeMessage(buff2)
#dm2.printDebugInfo()
