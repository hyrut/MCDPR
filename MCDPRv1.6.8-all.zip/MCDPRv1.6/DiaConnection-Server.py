from DiaMessage import *
import threading, thread
from socket import AF_INET, SOCK_STREAM
from socket import socket
import time

MAXBUFSIZ=65535
_SOCKET_TIMEOUT=3

class DiaConnection():
	def __init__(self, name, ip, port, type):
		self.setName(name)
		self.host=ip
		self.port=port
		self.type=type
		self.msgq=[]
		self.msgqlock=thread.allocate_lock()
		self.responseTriggers=[]
		self.responseTLock=thread.allocate_lock()
		self.quit=True
		self.quitDone=True
		
	def init(self, cer, cea, dwr, dwa):
		self.cer=cer
		self.cea=cea
		self.dwr=dwr
		self.dwa=dwa
		#self.dpr=dpr
		#self.dpa=dpa
		self.dwrTimer=None

	def loop(self):
		df=DiaFragmentor()
		self.quit=False
		self.quitDone=False
		while not self.quit:
			try:
				data=self.datasock.recv(MAXBUFSIZ)
				frags=df.Fragment(data)
				if len(frags)==0:
					continue
				self.msgqlock.acquire()
				for frag in frags:
					dmsg=DiaMessage()
					dmsg.decodeMessage(frag)
					if dmsg.getCommandCode()!=280:
						self.handleResponseTriggers(dmsg)
						self.msgq.append(dmsg)
					else:
						if dmsg.isRequest():
							self.handelDWR(dmsg.getHBHID(),dmsg.getEBEID())
				self.msgqlock.release()
			except Exception as e:
				if (str(type(e)).find("socket.timeout"))!=-1:
					continue
				else:
					self.quit=True
					print "\n    The connection "+self.getName()+" you are trying to send package have been down.\n    Please check the status of connection.\n    Use \"show connection "+self.getName()+"\" to check status.\n    Use start connection command to restart."
					print e
		self.quitDone=True
		
	def addResponseTrigger(self, respT):
		self.responseTLock.acquire()
		self.responseTriggers.append(respT)
		self.responseTLock.release()
		
	def delResponseTrigger(self, respT):
		self.responseTLock.acquire()
		i=0
		flag=False
		for item in self.responseTriggers:
			if item==respT:
				self.responseTriggers.pop(i)
				flag=True
				break
			i+=1
		self.responseTLock.release()		
		return flag
	
	def handleResponseTriggers(self, msg):
		self.responseTLock.acquire()
		for tr in self.responseTriggers:
			#print "find responseTrigger", tr.name
			if tr.isMatched(msg):
				#print "matched"
				tr.execute(msg)
		self.responseTLock.release()
			
	def handelDWR(self, HBHid, EBEid):
		self.dwa.setEBEID(EBEid)
		self.dwa.setHBHID(HBHid)
		self.send(self.wda)
		#print "send wda"
		
	def read(self):
		msgs=[]
		if len(self.msgq)==0:
			return []
		self.msgqlock.acquire()
		i=0
		while i< len(self.msgq):
			msgs.append(self.msgq.pop(0))
		self.msgqlock.release()
		return msgs
	
	def send(self,msg):
		if self.quitDone:
			return False
		buff=msg.convert()
		if buff=="":
			return False
		self.datasock.send(buff)
		return True
		
	def start(self):
		return self.connect()
		
	def end(self):
		return self.disconnect()
		
	def getInfo(self):
		if self.quitDone:
			r="Not running"
		else:
			r="Running"
		r+="\n"
		#self.responseTLock.acquire()
		#self.responseTriggers.append(respT)
		for item in self.responseTriggers:
			r+="      responseTrigger: "+item.getName()+"\n"
		#self.responseTLock.release()
		return r
			
	def isRunning():
		return not self.quitDone
		
	def setName(self, name):
		self.name=name
		
	def getName(self):
		return self.name
		
		
		
class DiaServer(DiaConnection):
	def connect(self):
		if self.quitDone!=True:
			return False
		try:
			self.server=socket(AF_INET, SOCK_STREAM)
			localADDR=(self.host,self.port)
			self.server.bind(localADDR)
			self.server.listen(5)
			datasock, addr=self.server.accept()
			self.datasock=datasock
			data=self.datasock.recv(MAXBUFSIZ)
			###########
			#Server need to be modified
			#CEA should have same EBEid and HBEid same CER
			dmsg=DiaMessage()
			dmsg.decodeMessage(data)
			EBEid=dmsg.getEBEID()
			HBHid=dmsg.getHBHID()
			self.cea.setHBHID(HBHid)
			self.cea.setEBEID(EBEid)
			###########
			self.datasock.send(self.cea.convert())
			self.datasock.settimeout(_SOCKET_TIMEOUT)
			self.thread=threading.Thread(target=self.loop,args=(self.socknum))
			self.thread.start()
		except Exception as e:
			#print e
			return False
		return True
		
	def disconnect(self):
		if self.quitDone==True:
			return False
		self.quit=True
		while not self.quitDone:
			pass
		self.datasock.close()
		self.server.close()
		return True
		
class DiaClient(DiaConnection):
	def connect(self):
		if self.quitDone!=True:
			return False
		try:
			self.datasock=socket(AF_INET, SOCK_STREAM)
			remoteADDR=(self.host,self.port)
			self.datasock.connect(remoteADDR)
			self.datasock.send(self.cer.convert())
			self.datasock.recv(MAXBUFSIZ)
			self.datasock.settimeout(_SOCKET_TIMEOUT)
			self.thread=threading.Thread(target=self.loop,args=())
			self.thread.start()
		except Exception as e:
			print e
			return False
		return True
		
	def disconnect(self):
		if self.quitDone==True:
			return False
		self.quit=True
		while not self.quitDone:
			#print self.quitDone
			pass
		#print self.quitDone
		self.datasock.close()
		return True

dmr=DiaMessageReader()		
dwa=dmr.createMessageFromXMLFile("dwa.xml")
cea=dmr.createMessageFromXMLFile("cea.xml")
server1=DiaServer("cn1", "172.18.6.158", 3868, "TCP")
server1.init(None,cea,None,dwa)
server1.connect()
time.sleep(2)
server1.disconnect()

