from xml.etree import ElementTree

intDict={"Integer32":0, "Unsigned32":1, "Enumerated":2, "VendorId":3, "AppId":4,"Time":5}
int64Dict={"Integer64":0, "Unsigned64":1}
stringDict={"OctetString":0, "IPAddress":1, "Time":2, "UTF8String":3, "DiameterIdentity":4, "DiameterURI":5, "IPFilterRule":6,"QOSFilterRule":7,"MIPRegistrationRequest":8}

filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\dictionary.xml"
doc=ElementTree.parse(filename)
root=doc.getroot()
avp=root.find("")
avps=root.findall("base/avp")
for a in avps:
	typeRoot=a.find("type")
	if typeRoot==None:
		type="grp"
	else:
		type=typeRoot.attrib["type-name"]
	avpName=a.attrib["name"]
	avpCode=a.attrib["code"]
	#print avpName, avpCode, type
	if intDict.has_key(type):
		t="int"
		print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
	elif int64Dict.has_key(type):
		t="int64"
		print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"			
	elif type=="grp":
		t="grp"
		print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
	elif stringDict.has_key(type):
		t="str"
		print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
	else:
		#print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		#print type
		t="str"
		print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
