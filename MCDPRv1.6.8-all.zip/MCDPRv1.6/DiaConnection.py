from DiaMessage import *
from DiaMessageBuffer import *
import threading, thread
from socket import AF_INET, SOCK_STREAM, IPPROTO_TCP
from socket import socket
import time

MAXBUFSIZ=65535
DEFAU_MAX_MSGQ_LEN=2000
_SOCKET_TIMEOUT=3

IPPROTO_INVALID=-1
IPPROTO_SCTP=132

DIA_CMD_CODE_DWR=280


class DiaConnection():
	def __init__(self, name, ip, port, protocol):
		self.setName(name)
		self.host=ip
		self.port=port
		self.setProtocol(protocol)
		self.msgq=[]
		self.maxmsgqlen=DEFAU_MAX_MSGQ_LEN
		self.msgqlock=thread.allocate_lock()
		self.responseTriggers=[]
		self.responseTLock=thread.allocate_lock()
		self.quit=True
		self.quitDone=True
		
	def init(self, cer, cea, dwr, dwa):
		self.cer=cer
		self.cea=cea
		self.dwr=dwr
		self.dwa=dwa
		#self.dpr=dpr
		#self.dpa=dpa
		self.dwrTimer=None
		
	def setProtocol(self, protocol):
		if protocol=="TCP":
			self.protocol=IPPROTO_TCP
		elif protocol=="SCTP":
			self.protocol=IPPROTO_SCTP
		else:
			self.protocol=IPPROTO_INVALID
		#6 for TCP, 132 for SCTP

	def loop(self):
		#df=DiaFragmentor()
		dmb=DiaMessageBuffer()
		dmb.setTimeout(_SOCKET_TIMEOUT)	
		self.quit=False
		self.quitDone=False
		while not self.quit:
			try:
				data=self.datasock.recv(MAXBUFSIZ)
				timestamp=time.time()
				dmb.receive(data, timestamp)
				frags=dmb.moreFrags()
				#print len(frags)
				if len(frags)==0:
					continue
				for frag in frags:
						self.handleFragment(frag)
			except Exception as e:
				if (str(type(e)).find("socket.timeout"))!=-1:
					continue
				else:
					self.quit=True
					print "\n    The connection "+self.getName()+" you are trying to send package have been down.\n    Please check the status of connection.\n    Use \"show connection "+self.getName()+"\" to check status.\n    Use start connection command to restart."
					print e
		self.quitDone=True
		
	
	def setMaxMsgQLen(self, l):
		self.maxmsgqlen=l
		self.clearMsgQHeaderMsg()
		
	def getMaxMsgQLen(self):
		return self.maxmsgqlen
	
	def addMsgToMsgQ(self, dmsg):
		self.msgqlock.acquire()
		self.msgq.append(dmsg)
		self.msgqlock.release()
		
	def clearMsgQHeaderMsg(self):
		self.msgqlock.acquire()
		if len(self.msgq)>self.getMaxMsgQLen():
			while len(self.msgq)>self.getMaxMsgQLen():
				self.msgq.pop()
		self.msgqlock.release()
	
	def clearMsgQ(self):
		self.msgqlock.acquire()
		self.msgq=[]
		self.msgqlock.release()		
		
	def handleFragment(self, frag):
		dmsg=DiaMessage()
		dmsg.decodeMessage(frag)
		if dmsg.getCommandCode()!=DIA_CMD_CODE_DWR:
			self.handleResponseTriggers(dmsg)
			self.addMsgToMsgQ(dmsg)
			self.clearMsgQHeaderMsg()
		else:
			if dmsg.isRequest():
				self.handleDWR(dmsg.getHBHID(),dmsg.getEBEID())
		#print len(self.msgq)
		
	def addResponseTrigger(self, respT):
		self.responseTLock.acquire()
		self.responseTriggers.append(respT)
		self.responseTLock.release()
		
	def delResponseTrigger(self, respT):
		self.responseTLock.acquire()
		i=0
		flag=False
		for item in self.responseTriggers:
			if item==respT:
				self.responseTriggers.pop(i)
				flag=True
				break
			i+=1
		self.responseTLock.release()		
		return flag
	
	def handleResponseTriggers(self, msg):
		self.responseTLock.acquire()
		for tr in self.responseTriggers:
			#print "find responseTrigger", tr.name
			if tr.isMatched(msg):
				#print "matched"
				tr.execute(msg)
		self.responseTLock.release()
			
	def handleDWR(self, HBHid, EBEid):
		self.dwa.setEBEID(EBEid)
		self.dwa.setHBHID(HBHid)
		self.send(self.dwa)
		#print "send wda"
		
	def read(self):
		msgs=[]
		if len(self.msgq)==0:
			return []
		self.msgqlock.acquire()
		i=0
		while i< len(self.msgq):
			msgs.append(self.msgq.pop(0))
		self.msgqlock.release()
		return msgs
	
	def send(self,msg):
		if self.quitDone:
			return False
		buff=msg.convert()
		if buff=="":
			return False
		self.datasock.send(buff)
		return True
		
	def start(self):
		return self.connect()
		
	def end(self):
		return self.disconnect()
		
	def getInfo(self):
		if self.quitDone:
			r="Not running"
		else:
			r="Running"
		r+="\n"
		#self.responseTLock.acquire()
		#self.responseTriggers.append(respT)
		for item in self.responseTriggers:
			r+="      responseTrigger: "+item.getName()+"\n"
		#self.responseTLock.release()
		r+="      message queue length:"
		r+=str(len(self.msgq))
		r+="\n"
		r+="      maximum message queue length(maxMsgQLen):"
		r+=str(self.getMaxMsgQLen())
		r+="\n"
		return r
			
	def isRunning():
		return not self.quitDone
		
	def setName(self, name):
		self.name=name
		
	def getName(self):
		return self.name
		
		
		
class DiaServer(DiaConnection):
	def connect(self):
		if self.quitDone!=True:
			return False
		try:
			if self.protocol==IPPROTO_INVALID:
				return
			self.server=socket(AF_INET, SOCK_STREAM, self.protocol)
			localADDR=(self.host,self.port)
			self.server.bind(localADDR)
			self.server.listen(5)
			datasock, addr=self.server.accept()
			self.datasock=datasock
			data=self.datasock.recv(MAXBUFSIZ)
			###########
			#Server need to be modified
			#CEA should have same EBEid and HBEid same CER
			dmsg=DiaMessage()
			dmsg.decodeMessage(data)
			EBEid=dmsg.getEBEID()
			HBHid=dmsg.getHBHID()
			self.cea.setHBHID(HBHid)
			self.cea.setEBEID(EBEid)
			###########
			self.datasock.send(self.cea.convert())
			self.datasock.settimeout(_SOCKET_TIMEOUT)
			self.thread=threading.Thread(target=self.loop,args=())
			self.thread.start()
		except Exception as e:
			#print e
			return False
		return True
		
	def disconnect(self):
		if self.quitDone==True:
			return False
		self.quit=True
		while not self.quitDone:
			pass
		self.datasock.close()
		self.server.close()
		return True
		
class DiaClient(DiaConnection):
	def connect(self):
		if self.quitDone!=True:
			return False
		try:
			if self.protocol==IPPROTO_INVALID:
				return
			self.datasock=socket(AF_INET, SOCK_STREAM,self.protocol)
			remoteADDR=(self.host,self.port)
			self.datasock.connect(remoteADDR)
			self.datasock.send(self.cer.convert())
			self.datasock.recv(MAXBUFSIZ)
			self.datasock.settimeout(_SOCKET_TIMEOUT)
			self.thread=threading.Thread(target=self.loop,args=())
			self.thread.start()
		except Exception as e:
			print e
			return False
		return True
		
	def disconnect(self):
		if self.quitDone==True:
			return False
		self.quit=True
		while not self.quitDone:
			#print self.quitDone
			pass
		#print self.quitDone
		self.datasock.close()
		return True

#dmr=DiaMessageReader()		
#dwa=dmr.createMessageFromXMLFile("dwa.xml")
#cer=dmr.createMessageFromXMLFile("cer.xml")
#client1=DiaClient("cn1", "192.168.168.173", 3868, "TCP")
#client1.init(cer,None,None,dwa)
#client1.connect()
#time.sleep(2)
#client1.disconnect()

