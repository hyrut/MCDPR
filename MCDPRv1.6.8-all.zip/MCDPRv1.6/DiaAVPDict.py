import os
from xml.etree import ElementTree
from DiaAVPConst import AVP_ARRAY_DEFAULT

CONFIG_FILE_NAME="AVPDict.xml"

class DiaAVPDict:
	__avpDict={}
	@classmethod
	def init(cls_obj):
		#print "init"
		DiaAVPDict.__avpDict={}
		if not os.path.exists(CONFIG_FILE_NAME):
			DiaAVPDict.__avpDict=AVP_ARRAY_DEFAULT
		else:
			DiaAVPDict.createAVPDictFromXmlFile(CONFIG_FILE_NAME)
	
	@classmethod	
	def createAVPDictFromXmlFile(cls_obj, xmlFileName):
		doc=ElementTree.parse(xmlFileName)
		root=doc.getroot()
		vendorRoots=root.findall("Vendor")
		for vendorRoot in vendorRoots:
			vendorCode=int(vendorRoot.attrib["vendorcode"])
			DiaAVPDict.__avpDict[vendorCode]={}
			avpRoots=vendorRoot.findall("AVP")
			for avpRoot in avpRoots:
				avpCode=int(avpRoot.attrib["code"])
				avpName=avpRoot.attrib["name"]
				avpType=avpRoot.attrib["type"]
				DiaAVPDict.__avpDict[vendorCode][avpCode]={"name":avpName, "type":avpType}
		#print self.avpDict
		
	@classmethod
	def getAVPDict(cls_obj):
		return DiaAVPDict.__avpDict
	
	
DiaAVPDict.init()
#print DiaAVPDict.getAVPDict()[10415][1490]
#print DiaAVPDict.getAVPDict()

	