import sys, os
from DiaMessage import *
from DiaConnection import *
from DiaRedirector import *
from DiaResponseTrigger import *
from DiaMessageMatch import *
from DiaRedirectorMM import *

_PROMOT_="MCDPR!# "
NULL_MSG_NAME="SYS_NULL_MSG"
MCDPR_VER="1.6.08"
DATE_TIME_FORMAT="%Y-%m-%d %H:%M:%S"

class DataCenter():
	def __init__(self):
		self.objects={}
		
	def addObject(self, key, obj, type, info):
		self.objects[key]=[obj, type, info]
		
	def removeObject(self, key):
		self.objects.pop(key)
		
	def getObject(self, key):
		if key in self.objects:
			return self.objects[key]
		return None

	def getObjectListByType(self, type):
		r={}
		for item in self.objects:
			#print item, type
			if self.objects[item][1]==type:
				r[item]=self.objects[item]
		return r
class CommandExecutor():		
	def execCommand(self, dataCenter, cmdName, cmdParams):
		ce=None
		if cmdName=="create":
			ce=createCommandExecutor()
			#ce.execCommand(self.dataCenter, cmdParams)
		elif cmdName=="start":
			ce=startCommandExecutor()
		elif cmdName=="end":
			ce=endCommandExecutor()
		elif cmdName=="send":
			ce=sendCommandExecutor()
		elif cmdName=="show":
			ce=showCommandExecutor()
		elif cmdName=="change":
			ce=changeCommandExecutor()
		elif cmdName=="sleep":
			ce=sleepCommandExecutor()
		elif cmdName=="pause":
			ce=pauseCommandExecutor()
		elif cmdName=="help":
			ce=helpCommandExecutor()
		if ce!=None:
			ce.execCommand(dataCenter,cmdParams)
		else:
			print "    Unsupported command -", cmdName
			
class createCommandExecutor(CommandExecutor):
	@classmethod
	def help(cls_obj):
		ce=createCommandExecutor()
		print "    --------------------------------------------------------------------"
		ce.printCreateMessageHelp()
		print "    --------------------------------------------------------------------"
		ce.printCreateMessageMatchHelp()
		print "    --------------------------------------------------------------------"		
		ce.printCreateConnectionHelp()
		print "    --------------------------------------------------------------------"
		ce.printCreateRedirectorHelp()
		print "    --------------------------------------------------------------------"
		ce.printCreateRedirectorMMHelp()
		print "    --------------------------------------------------------------------"
		ce.printCreateResponseTriggerHelp()
		
	def printCreateMessageHelp(self):
		print "    Usage: create message <message-object-name> <message-conf-filename>"
		print "    Example: create message cer cer.xml"
	
	def printCreateConnectionHelp(self):
		print "    Usage: create connection <connection-object-name> <connection-type(client/server)> <ip> <port> <connection-protocol(TCP/SCTP)> <cer/cea-message-object-name> <dwa-message-object-name>"
		print "    Example: create connection cn1 client 192.168.168.173 3868 TCP cer dwa"
		print "    Example: create connection cn1 server 172.18.6.145 3868 TCP cea dwa"
		
	def printCreateRedirectorHelp(self):
		print "    Usage: create redirector <redirector-object-name> <connection1-name> <connection2-name>"
		print "    Example: create redirector rd1 cn1 cn2"
		
	def printCreateResponseTriggerHelp(self):
		print "    Usage: create responseTrigger <responseTrigger-object-name> <match-object-name> <target-connection-object-name> <message-object-name>"
		print "    Example: create responseTrigger rspt1 msgMatch1 cn2 uda1"
		print "    Note: this command is used as, when trigger's condition is matched with messageMatch object, it will send out the message object in target connection you assigned."
		print "    And, command \"change connection <connection-object-name> addResponseTrigger rspt1\" is used to make the responseTrigger effect on connection object."
		print "    So, \"create responseTrigger rspt1 msgMatch1 cn2 uda1\" and \"change connection cn1 addResponseTrigger rspt1\", means, if got a message from cn1, and matched the messageMatch's condition, rspt1 will send out message uda1 in connection cn2."

	def printCreateMessageMatchHelp(self):
		print "    Usage: create messageMatch <messageMatch-object-name> <messageMatch-conf-filename>"
		print "    Example: create messageMatch match1 msgMatch.xml"
		
	def printCreateRedirectorMMHelp(self):
		print "    Usage: create redirectorMM <redirectorMM-object-name> <redirectorMM-conf-filename>"
		print "    Example: create redirectorMM rmm1 mm1.xml"
		
	def execCommand(self, DataCenter, cmdParams):
		if len(cmdParams)<3:
			print "    Parameters is not enough"
			return
		createObjectType=cmdParams[0]
		createObjectName=cmdParams[1]
		createOtherParams=cmdParams[2:]
		if createObjectType!="message" and createObjectType!="connection" and createObjectType!="redirector" and createObjectType!="responseTrigger" and createObjectType!="messageMatch" and createObjectType!="redirectorMM":
			print "    Type", createObjectType, "is not supported."
			return 
		if createObjectType=="message":
			if len(createOtherParams)!=1:
				self.printCreateMessageHelp()
			else:
				if createObjectName==NULL_MSG_NAME:
					print "    Can't overwrite System Null Message."
					return
				dmr=DiaMessageReader()
				msg=dmr.createMessageFromXMLFile(createOtherParams[0])
				if msg==None:
					print "    Can't create message from file", createOtherParams[0]
					print "    Make sure the file is exist and with right grammar."
					return
				else:
					msg.setName(createObjectName)
					DataCenter.addObject(createObjectName,msg, createObjectType, "")
		elif createObjectType=="connection":
			#print createOtherParams
			if len(createOtherParams)!=6 and len(createOtherParams)!=7:
				self.printCreateConnectionHelp()
			else:
				#cnName=createOtherParams[0]
				cnClientServerType=createOtherParams[0]
				cnIP=createOtherParams[1]
				cnPort=int(createOtherParams[2])
				cnProtocol=createOtherParams[3]
				cnCERAObjectName=createOtherParams[4]
				cnDWAObjectName=createOtherParams[5]
				cera=DataCenter.getObject(cnCERAObjectName)
				if cera==None:
					print "    Can't find message object", cnCERAObjectName
					return 
				ceraMsg=cera[0]
				#print cera
				dwa=DataCenter.getObject(cnDWAObjectName)
				if dwa==None:
					print "    Can't find message object ", cnDWAObjectName
					return 
				dwaMsg=dwa[0]
				if len(createOtherParams)==7:
					cnDWRObjectName=createOtherParams[6]
					dwr=DataCenter.getObject(cnDWRObjectName)
					if dwr==None:
						print "    Can't find message object ", cnDWRObjectName
						return 
					dwrMsg=dwr[0]
				else:
					dwrMsg=None
				#print dwrMsg
				if cnClientServerType=="client":
					cn=DiaClient(createObjectName,cnIP,cnPort,cnProtocol)
					cn.init(ceraMsg, None, dwrMsg, dwaMsg)
					DataCenter.addObject(createObjectName, cn, createObjectType, cnClientServerType+" "+cnIP+":"+str(cnPort)+" "+cnProtocol)
				elif cnClientServerType=="server":
					cn=DiaServer(createObjectName,cnIP,cnPort,cnProtocol)
					cn.init(None, ceraMsg, dwrMsg, dwaMsg)
					DataCenter.addObject(createObjectName, cn, createObjectType, cnClientServerType+" "+cnIP+":"+str(cnPort)+" "+cnProtocol)
				else:
					self.printCreateConnectionHelp()
		elif createObjectType=="redirector":
			if len(createOtherParams)!=2:
				self.printCreateRedirectorHelp()
			else:
				cn1Name=createOtherParams[0]
				cn2Name=createOtherParams[1]
				cn1=DataCenter.getObject(cn1Name)
				if cn1==None:
					print "    Can't find connection object", cn1Name
					return
				cn2=DataCenter.getObject(cn2Name)
				#print cn2
				if cn2==None:
					print "    Can't find connection object", cn2Name
					return
				cn1Ins=cn1[0]
				cn2Ins=cn2[0]
				dr=DiaRedirector(cn1Ins,cn2Ins)
				DataCenter.addObject(createObjectName, dr, createObjectType, cn1Name+" ----> " +cn2Name)
		elif createObjectType=="responseTrigger":
			if len(createOtherParams)!=3:
				self.printCreateResponseTriggerHelp()
			else:
				msgMatchObjectName=createOtherParams[0]
				msgMatchObject=DataCenter.getObject(msgMatchObjectName)
				targetConnectionName=createOtherParams[1]
				targetConnectionObject=DataCenter.getObject(targetConnectionName)
				responseObjectName=createOtherParams[2]
				responseObject=DataCenter.getObject(responseObjectName)
				if targetConnectionObject==None:
					print "    Can't find connection object", targetConnectionObject
					return					
				if responseObject==None:
					print "    Can't find message object", responseObjectName
					return
				if msgMatchObject==None:
					print "    Can't find messageMatch object", responseObjectName
					return				
				rt=DiaResponseTrigger()
				rt.init(createObjectName, msgMatchObject[0], targetConnectionObject[0],responseObject[0])
				DataCenter.addObject(createObjectName,rt,createObjectType,"")
		elif createObjectType=="messageMatch":
			if len(createOtherParams)!=1:
				self.printCreateMessageMatchHelp()
			else:
				dmm=DiaMessageMatch()
				r=dmm.createFromXMLFile(createOtherParams[0])
				if r==False:
					print "    Can't create messageMatch from file", createOtherParams[0]
					print "    Make sure the file is exist and with right grammar."
					return
				else:
					dmm.setName(createObjectName)
					DataCenter.addObject(createObjectName,dmm, createObjectType, "")
		elif createObjectType=="redirectorMM":
			#create redirectorMM rmm1 mm1.xml
			if len(createOtherParams)!=1:
				self.printCreateRedirectorMMHelp()
			else:
				drmm=DiaRedirectorMM()
				r=drmm.createFromXMLFile(createOtherParams[0])
				if r==False:
					print "    Can't create messageMatch from file", createOtherParams[0]
					print "    Make sure the file is exist and with right grammar."
					return
				else:
					drmm.setName(createObjectName)
					DataCenter.addObject(createObjectName,drmm, createObjectType, "")
				
class startCommandExecutor(CommandExecutor):
	@classmethod
	def help(cls_obj):
		ce=startCommandExecutor()
		ce.printStartCommandHelp()
		
	def printStartCommandHelp(self):
		print "    Usage: start <object-type> <object-name>"
		print "    Example: start connection cn1"
		print "    Example: start redirector rd1"
	
	def execCommand(self, DataCenter, cmdParams):
		if len(cmdParams)!=2:
			self.printStartCommandHelp()
			return
		startObjectType=cmdParams[0]
		startObjectName=cmdParams[1]
		if startObjectType!="connection" and startObjectType!="redirector":
			print "    Object", startObjectName, "do not support start method."
			return
		#Now do not distinguish the type, just call the start method of the object
		obj=DataCenter.getObject(startObjectName)
		if obj!=None:
			if obj[0].start()==False:
				print "    Start Object", startObjectName, "failed."
				print "    Please check the connection parameters and status."
		else:
			print "    Can't find object", startObjectName
				
class endCommandExecutor(CommandExecutor):
	@classmethod
	def help(cls_obj):
		ce=endCommandExecutor()
		ce.printEndCommandHelp()
		
	def printEndCommandHelp(self):
		print "    Usage: end <object-type> <object-name>"
		print "    Example: end connection cn1"
		print "    Example: end redirector rd1"
	
	def execCommand(self, DataCenter, cmdParams):
		if len(cmdParams)!=2:
			self.printEndCommandHelp()
			return
		endObjectType=cmdParams[0]
		endObjectName=cmdParams[1]
		if endObjectType!="connection" and endObjectType!="redirector":
			print "    Type", endObjectType, "do not support end method."
			return
		#Now do not distinguish the type, just call the end method of end of the object
		obj=DataCenter.getObject(endObjectName)
		if obj!=None:
			if obj[0].end()==False:
				print "    End Object", endObjectName, "failed."
				print "    Please check the connection parameters and status."
		else:
			print "    Can't find object", endObjectName
			
class sendCommandExecutor(CommandExecutor):
	@classmethod
	def help(cls_obj):
		ce=sendCommandExecutor()
		ce.printSendCommandHelp()
		
	def printSendCommandHelp(self):
		print "    Usage: send connection <connection-object-name> <message-object-name>"
		print "    Example: send connection cn1 idr"
		
	def execCommand(self, DataCenter, cmdParams):
		if len(cmdParams)!=3:
			self.printSendCommandHelp()
			return 
		sendObjectType=cmdParams[0]
		sendObjectName=cmdParams[1]
		msgObjectName=cmdParams[2]
		if sendObjectType!="connection":
			print "    Type", sendObjectType, "do not support send method."
			return
		sendObject=DataCenter.getObject(sendObjectName)
		if sendObject==None:
			print "    Can't find object", sendObjectName
			return
		msg=DataCenter.getObject(msgObjectName)
		if msg==None:
			print "    Can't find object", msgObjectName
			return
		if sendObject[0].send(msg[0])==False:
			print "    Send message failed, check the state of connection " + sendObjectName
			
		
class showCommandExecutor(CommandExecutor):
	@classmethod
	def help(cls_obj):
		ce=showCommandExecutor()
		ce.printShowCommandHelp()
		
	def printShowCommandHelp(self):
		print "    Usage: show message/connection/redirector/redirectorMM/responseTrigger/messageMatch/all"
		
	def showObjectByType(self, DataCenter, showObjectType):
		showObjectList=DataCenter.getObjectListByType(showObjectType)
		#print showObjectList
		l=66-len(showObjectType)
		i=0
		s=""
		while i<l:
			s+="="
			i+=1
		t="    ==["+showObjectType+"]"+s
		print t
		for item in showObjectList:
			s="      "+item+": "+showObjectList[item][2]+" "
			#print showObjectList[item]
			if showObjectList[item][0]!=None:
				s+=showObjectList[item][0].getInfo()
			print s
			#print showObjectList[item][0].getInfo()
		print 
		
	def execCommand(self, DataCenter, cmdParams):
		if len(cmdParams)!=1:
			self.printShowCommandHelp()
			return
		showObjectType=cmdParams[0]
		if showObjectType!="connection" and showObjectType!="message" and showObjectType!="redirector" and showObjectType!="history" and showObjectType!="responseTrigger" and showObjectType!="messageMatch" and showObjectType!="redirectorMM" and showObjectType!="all":
			print "    Type", showObjectType, "do not support show method."
			return
		if showObjectType=="all":
			#print "    === [connection] ======================================================="
			self.showObjectByType(DataCenter,"connection")
			#print "    === [message] =========================================================="
			self.showObjectByType(DataCenter,"message")
			#print "    === [redirector] ======================================================="
			self.showObjectByType(DataCenter,"redirector")
			#print "    === [redirectorMM] ====================================================="
			self.showObjectByType(DataCenter,"redirectorMM")
			#print "    === [responseTrigger] =================================================="
			self.showObjectByType(DataCenter,"responseTrigger")
			#print "    === [messageMatch] ====================================================="
			self.showObjectByType(DataCenter,"messageMatch")
		else:
			self.showObjectByType(DataCenter,showObjectType)
			
class sleepCommandExecutor(CommandExecutor):
	@classmethod
	def help(cls_obj):
		ce=sleepCommandExecutor()
		ce.printSleepCommandHelp()

	def printSleepCommandHelp(self):
		print "    Usage: sleep <time-in-millisecond>"
		
	def execCommand(self, DataCenter, cmdParams):
		if len(cmdParams)!=1:
			self.printSleepCommandHelp()
			return
		try:
			usecs=int(cmdParams[0])
			if usecs<0:
				print "    Can't sleep with a negative value."
				return
			secs=float(usecs)/1000
		except:
			print "    Parameter of sleep should be in integer format."
			return
		time.sleep(secs)
		
class changeCommandExecutor(CommandExecutor):
	def formatAVPString(self, avpString):
		avpString=avpString.strip("\"")
		#print "haha",avpString
		i=0
		r=""
		while i<len(avpString):
			c=avpString[i:i+2]
			v=avpString[i+2:i+4]
			#print c
			if c!="\\x":
				return avpString
				#Malform avpString, return original string.
			else:
				try:
					r+=chr(int(v,16))
				except Exception as e:
					print "    Malform hex string, it should be like \\x0c\\x0d, not \\xc\\x0d or \\xc\\xd"
					raise e
			i+=4
		return r
	
	@classmethod
	def help(cls_obj):
		ce=changeCommandExecutor()
		ce.printChangeCommandHelp()
		
		
	def printChangeCommandHelp(self):
		print "    --------------------------------------------------------------------"
		print "    Usage: change redirector <redirector-object-name> enableReplaceDestHostName <hostname>"
		print "    Usage: change redirector <redirector-object-name> enableReplaceDestRealm <realmName>"
		print "    Usage: change redirector <redirector-object-name> addMessageRedirectRestriction <messageMatch-object-name>"
		print "    Usage: change redirector <redirector-object-name> delMessageRedirectRestriction <index>"
		print "    Usage: change redirector <redirector-object-name> addRedirectorMM <MM-Point(entry/exit)> <messageMatch-object-name> <redirectorMM-object-name>"
		print "    Usage: change redirector <redirector-object-name> delRedirectorMM <MM-Point(entry/exit)> <index>"		
		print "    Example: change redirector rd1 enableReplaceDestHostName host.test.com"
		print "    Example: change redirector rd1 enableReplaceDestRealm test.com"
		print "    Example: change redirector rd2 addMessageRedirectRestriction msgMatch1"
		print "    Example: change redirector rd2 delMessageRedirectRestriction 0"
		print "    Example: change redirector rd2 addRedirectorMM entry msgMatch1 mm1"
		print "    Example: change redirector rd2 delRedirectorMM exit 0"
		print "    Notes: <avpPath> form is: vendor/avpCode[sameAVPIndex]->vendor/avpCode[sameAVPIndex]->vendor/avpCode[sameAVPIndex]"
		print "    Example: avpPath could be: 10415/517[0]->10415/519[1]->10415/507[0]"
		print "    --------------------------------------------------------------------"
		print "    Usage: change connection <connection-object-name> addResponseTrigger <responseTrigger-object-name>"
		print "    Usage: change connection <connection-object-name> removeResponseTrigger <responseTrigger-object-name>"
		print "    Usage: change connection <connection-object-name> maxMsgQLen <max-message-queue-length>"
		print "    Usage: change connection <connection-object-name> clearMsgQ"
		print "    Example: change connection cn1 addResponseTrigger rspt1"
		print "    Example: change connection cn1 removeResponseTrigger rspt1"
		print "    Example: change connection cn1 maxMsgQLen 20000"
		print "    Example: change connection cn1 clearMsgQ"
		
	def execCommand(self, DataCenter, cmdParams):
		if len(cmdParams)<3:
			self.printChangeCommandHelp()
			return
		changeObjectType=cmdParams[0]
		changeObjectName=cmdParams[1]
		changeObjectCmd=cmdParams[2]
		changeObjectOtherParams=cmdParams[3:]
		if changeObjectType!="redirector" and changeObjectType!="connection":
			print "    Type", changeObjectType, "do not support change method."
			return
		changeObject=DataCenter.getObject(changeObjectName)
		if changeObject==None:
			print "    Can't find object", changeObjectName
			return
		if changeObjectType=="redirector" and changeObjectCmd=="enableReplaceDestHostName":
			if len(changeObjectOtherParams)!=1:
				self.printChangeCommandHelp()
				return
			hostName=changeObjectOtherParams[0]
			rd=changeObject[0]
			rd.enableReplaceDestHostName(hostName)
		elif changeObjectType=="redirector" and changeObjectCmd=="enableReplaceDestRealm":
			if len(changeObjectOtherParams)!=1:
				self.printChangeCommandHelp()
				return
			realmName=changeObjectOtherParams[0]
			rd=changeObject[0]
			#print "change"
			rd.enableReplaceDestRealm(realmName)
		elif changeObjectType=="redirector" and changeObjectCmd=="addMessageRedirectRestriction":
			if len(changeObjectOtherParams)!=1:
				self.printChangeCommandHelp()
				return
			msgMatchObjectName=changeObjectOtherParams[0]
			msgMatchObject=DataCenter.getObject(msgMatchObjectName)
			if msgMatchObject==None:
				print "    Can't find messageMatch object", msgMatchObjectName
				return			
			if isinstance(msgMatchObject[0], DiaMessageMatch)==False:
				print "    Object ", msgMatchObjectName, "is not a messageMatch object."
				return						
			rd=changeObject[0]
			rd.disableMessageRedirect(msgMatchObject[0])
		elif changeObjectType=="redirector" and changeObjectCmd=="delMessageRedirectRestriction":
			if len(changeObjectOtherParams)!=1:
				self.printChangeCommandHelp()
				return 
			try:
				messageRedirectRestrictionRuleIndex=int(changeObjectOtherParams[0])
			except Exception as e:
				print "   ",e
				return 
			rd=changeObject[0]
			if rd.removeDisableMessageRedirectRule(messageRedirectRestrictionRuleIndex)==False:
				print "    Index", messageRedirectRestrictionRuleIndex,"does not exist, removal failed."
		elif changeObjectType=="redirector" and changeObjectCmd=="addRedirectorMM":
			if len(changeObjectOtherParams)!=3:
				self.printChangeCommandHelp()
				return
			entryOrExitPoint=changeObjectOtherParams[0]
			msgMatchObjectName=changeObjectOtherParams[1]
			MMObjectName=changeObjectOtherParams[2]
			msgMatchObject=DataCenter.getObject(msgMatchObjectName)
			MMObject=DataCenter.getObject(MMObjectName)
			if msgMatchObject==None:
				print "    Can't find messageMatch object", msgMatchObjectName
				return			
			if MMObject==None:
				print "    Can't find redirectorMM object", msgMatchObjectName
				return		
			if isinstance(msgMatchObject[0], DiaMessageMatch)==False:
				print "    Object ", msgMatchObjectName, "is not a messageMatch object."
				return			
			if isinstance(MMObject[0], DiaRedirectorMM)==False:
				print "    Object ", MMObjectName, "is not a redirectorMM object."
				return						
			rd=changeObject[0]
			if entryOrExitPoint=="entry":
				#print msgMatchObject[0],MMObject[0]
				rd.addEntryPointRedirectorMM(msgMatchObject[0],MMObject[0])
			elif entryOrExitPoint=="exit":
				rd.addExitPointRedirectorMM(msgMatchObject[0],MMObject[0])
			else:
				print "    Please assign the entry/exit point in parameters."
				return 
		elif changeObjectType=="redirector" and changeObjectCmd=="delRedirectorMM":
			if len(changeObjectOtherParams)!=2:
				self.printChangeCommandHelp()
				return 
			try:
				entryOrExitPoint=changeObjectOtherParams[0]
				redirectorMMIndex=int(changeObjectOtherParams[1])
			except Exception as e:
				print "   ",e
				return 
			rd=changeObject[0]
			if entryOrExitPoint=="entry":
				if rd.removeEntryPointRedirectorMM(redirectorMMIndex)==False:
					print "    Index", redirectiorMMIndex,"does not exist, removal failed."
			elif entryOrExitPoint=="exit":
				if rd.removeExitPointRedirectorMM(redirectorMMIndex)==False:
					print "    Index", redirectiorMMIndex,"does not exist, removal failed."
			else:
				print "    Please assign the entry/exit point in parameters."
				return 
		elif changeObjectType=="connection" and changeObjectCmd=="addResponseTrigger":
			if len(changeObjectOtherParams)!=1:
				self.printChangeCommandHelp()
				return 
			changeObject=DataCenter.getObject(changeObjectName)
			if changeObject==None:
				print "    Can't find connection object", changeObjectName
				return 
			responseTriggerName=changeObjectOtherParams[0]
			responseTriggerObject=DataCenter.getObject(responseTriggerName)
			if responseTriggerObject==None:
				print "    Can't find responseTrigger object", responseTriggerName
				return 
			connection=changeObject[0]
			responseTrigger=responseTriggerObject[0]
			connection.addResponseTrigger(responseTrigger)
		elif changeObjectType=="connection" and changeObjectCmd=="removeResponseTrigger":
			if len(changeObjectOtherParams)!=1:
				self.printChangeCommandHelp()
				return 
			changeObject=DataCenter.getObject(changeObjectName)
			if changeObject==None:
				print "    Can't find connection object", changeObjectName
				return 
			responseTriggerName=changeObjectOtherParams[0]
			responseTriggerObject=DataCenter.getObject(responseTriggerName)
			if responseTriggerObject==None:
				print "    Can't find responseTrigger object", responseTriggerName
				return 
			connection=changeObject[0]
			responseTrigger=responseTriggerObject[0]
			if connection.delResponseTrigger(responseTrigger)==False:
				print "    Connection", changeObjectName,"does not have this responseTrigger"
		elif changeObjectType=="connection" and changeObjectCmd=="maxMsgQLen":
			if len(changeObjectOtherParams)!=1:
				self.printChangeCommandHelp()
				return 
			changeObject=DataCenter.getObject(changeObjectName)
			if changeObject==None:
				print "    Can't find connection object", changeObjectName
				return 
			connection=changeObject[0]
			strMaxMsgQLen=changeObjectOtherParams[0]
			if not strMaxMsgQLen.isdigit() or int(strMaxMsgQLen)>20000 or int(strMaxMsgQLen)<100:
				print "    Please input an integer for maxMsgQLen value (b/w 100 to 20000)."
				return
			connection.setMaxMsgQLen(int(changeObjectOtherParams[0]))
		elif changeObjectType=="connection" and changeObjectCmd=="clearMsgQ":
			if len(changeObjectOtherParams)!=0:
				self.printChangeCommandHelp()
				return 
			changeObject=DataCenter.getObject(changeObjectName)
			if changeObject==None:
				print "    Can't find connection object", changeObjectName
				return 
			connection=changeObject[0]
			connection.clearMsgQ()
		else:
			self.printChangeCommandHelp()
			
			
class helpCommandExecutor(CommandExecutor):
	def  execCommand(self, DataCenter, cmdParams):
		if len(cmdParams)==0:
			print help2()
			return
		commandType=cmdParams[0]
		if commandType=="create":
			createCommandExecutor.help()
		elif commandType=="start":
			startCommandExecutor.help()
		elif commandType=="end":
			endCommandExecutor.help()
		elif commandType=="send":
			sendCommandExecutor.help()
		elif commandType=="show":
			showCommandExecutor.help()
		elif commandType=="change":
			changeCommandExecutor.help()
		elif commandType=="sleep":
			sleepCommandExecutor.help()
		elif commandType=="pause":
			pauseCommandExecutor.help()
		elif commandType=="repeat":
			CommandRepeatProcedure.help()
		elif commandType=="help":
			print help2()
		return
	
class pauseCommandExecutor(CommandExecutor):
	@classmethod
	def help(cls_obj):
		ce=pauseCommandExecutor()
		ce.printPauseCommandHelp()
		
	def printPauseCommandHelp(self):
		print "    --------------------------------------------------------------------"
		print "    Usage: pause"
		print "    Usage: pause until <data> <time>"
		print "    Example: pause"
		print "    Example: pause until 2015-11-19 12:00:00"

		
	def execCommand(self, DataCenter, cmdParams):
		if len(cmdParams)==0:
			r=raw_input("    MCDPR command-line is paused.\n    Connection, redirector and responseTrigger are still in working status.\n    Press Enter key to continue the command-line...\n")
			return 
		elif len(cmdParams)==3 and cmdParams[0]=="until":
			try:
				i=1
				targetTimeStr=""
				targetTimeStr=cmdParams[1]+" "+cmdParams[2]
				targetTime=time.strptime(targetTimeStr, DATE_TIME_FORMAT)
				targetTimeFloat=time.mktime(targetTime)
				nowTimeFloat=time.time()
				print "    MCDPR command-line is paused.\n    Connection, redirector and responseTrigger are still in working status.\n    Paused time is", time.strftime(DATE_TIME_FORMAT,time.localtime(nowTimeFloat))
				while nowTimeFloat<targetTimeFloat:
					nowTimeFloat=time.time()
					print "    Now, time is: ", time.strftime(DATE_TIME_FORMAT,time.localtime(nowTimeFloat))+"\r",
					time.sleep(0.1)
				print "    Now, time is: ", time.strftime(DATE_TIME_FORMAT,time.localtime(nowTimeFloat))+"        "
				print "    Command pause exited successfully."
			except Exception as e:
				print "   ",e
				print "    pause command meet some problems, please check the command you entered."
			#print "    MCDPR command-line is paused.\n Paused time is "
		else:
			self.printPauseCommandHelp()
			return
			
class CommandAnalyzer():
	def isExecutable(self, command):
		if command=="":
			return False
		if command[0]==";":
			return False
		return True

	def analyzeCommand(self, command):
		items=command.split(" ")
		r=[]
		for item in items:
			it=item.strip()
			if  it!="":
				r.append(it)
			#print item.strip()
		return r
		
CMD_NAME_REPEAT="repeat"
CMD_NAME_REPEAT_DONE="repeat-done"
		
class CommandProcedure(object):#Need call super method, so inherit from object class.
	def __init__(self, DataCenter):
		self.childProcedure=None
		self.ce=CommandExecutor()
		self.dataCenter=DataCenter
		self.repeatProcedureCommandName=[CMD_NAME_REPEAT]
		self.repeatProcedureExitCommandName=[CMD_NAME_REPEAT_DONE]
		
	def createRepeatProcedureByCommandName(self, cmdName, cmdParams, DataCenter):
		foundFlag=False
		for cn in self.repeatProcedureCommandName:
			if cmdName==cn:
				foundFlag=True
		if foundFlag==True :
			if cmdParams==[] or cmdParams==None or not cmdParams[0].isdigit():
				print "   ",CMD_NAME_REPEAT," procedure control command need a parameter with integer type."
				return None
			else:
				if int(cmdParams[0])<=0:
					print "   ",CMD_NAME_REPEAT," need a value >0, handled it as 1."
				return CommandRepeatProcedure(DataCenter)
		return None
		
	def createProcedureByCommandName(self, cmdName, cmdParams, DataCenter):
		ret=self.createRepeatProcedureByCommandName(cmdName, cmdParams, DataCenter)
		if ret!=None:
			return ret
		return None
				
	def setChildProcedure(self, childProcedure):
		self.childProcedure=childProcedure
		
	def getChildProcedure(self):
		return self.childProcedure
	
	def clearChildProcedrue(self):
		self.childProcedure=None
		
	def registerProcedureExitCallBack(self, callbackFuncPtr):
		self.procedureExitCallbackFuncPtr=callbackFuncPtr

	def subProcedureExitCallBack(self):
		#print "clean"
		self.clearChildProcedrue()
		
		
		
class CommandSerializeProcedure(CommandProcedure):		
	def interpretCommand(self, cmdName, cmdParams):
		if self.getChildProcedure()!=None:
			self.getChildProcedure().interpretCommand(cmdName, cmdParams)
		else:
			nextCommandProcedure=self.createProcedureByCommandName(cmdName, cmdParams,self.dataCenter)
			if nextCommandProcedure!=None:
				self.setChildProcedure(nextCommandProcedure)
				self.getChildProcedure().registerProcedureExitCallBack(self.subProcedureExitCallBack)
				self.getChildProcedure().interpretCommand(cmdName, cmdParams)
			else:
				#print self
				self.interpretCommandx(cmdName, cmdParams)
				
	def interpretCommandx(self, cmdName, cmdParams):
		self.ce.execCommand(self.dataCenter,cmdName, cmdParams)
			

class CommandRepeatProcedure(CommandProcedure):
	def __init__(self, DataCenter):
		self.cmdNames=[]
		self.cmdParamsList=[]
		self.repeatTime=-1
		super(CommandRepeatProcedure,self).__init__(DataCenter)

	@classmethod
	def help(cls_obj):
		cls_obj.printRepeatCommandHelp()
		
	@classmethod
	def printRepeatCommandHelp(self):
		print "    Usage:"
		print "    repeat <times>"
		print "    <command>"
		print "    <command>"
		print "    ..."
		print "    repeat-done"
		print "    Example:"
		print "    repeat 3"
		print "    send connection cn1 idr1"
		print "    repeat-done"
		
	def addCommand(self, cmdName, cmdParams):
		self.cmdNames.append(cmdName)
		self.cmdParamsList.append(cmdParams)
		
	def interpretCommand(self, cmdName, cmdParams):
		#print self.cmdNames, cmdName
		if len(self.cmdNames)==0 and cmdName==CMD_NAME_REPEAT and self.repeatTime==-1:	#enter first time, need take the repeat time for this procedure
			#print "set"
			self.repeatTime=int(cmdParams[0])
			return
			#print self.repeatTime
		else:
			self.addCommand(cmdName,cmdParams)
			self.interpretCommandx(cmdName, cmdParams)
			
	def executeLoopOnce(self):
		i=0
		while i<len(self.cmdNames)-1:
			self.interpretCommandx(self.cmdNames[i],self.cmdParamsList[i])
			i+=1
			
	def interpretCommandx(self, cmdName, cmdParams):
		if self.getChildProcedure()!=None:
			self.getChildProcedure().interpretCommand(cmdName, cmdParams)
		else:
			nextCommandProcedure=self.createProcedureByCommandName(cmdName, cmdParams,self.dataCenter)
			if nextCommandProcedure!=None:
				self.setChildProcedure(nextCommandProcedure)
				self.getChildProcedure().registerProcedureExitCallBack(self.subProcedureExitCallBack)
				self.getChildProcedure().interpretCommand(cmdName, cmdParams)
			elif cmdName==CMD_NAME_REPEAT_DONE:
				#print self
				#print "need repeat ", self.repeatTime, "times"
				#print self.cmdNames
				if cmdParams!=[]:
					print "   ",CMD_NAME_REPEAT_DONE, "do not need any parameter, parameter(s) will be ignored."
				self.repeatTime-=1
				while self.repeatTime>0:
					self.executeLoopOnce()
					self.repeatTime-=1
				self.procedureExitCallbackFuncPtr()
			else:
				#pass
				#print self
				self.ce.execCommand(self.dataCenter,cmdName,cmdParams)
			#print "got", self.repeatTime, self.cmdNames

		

class CommandInterpretor(object, CommandAnalyzer):
	def __init__(self, DataCenter):
		self.dataCenter=DataCenter
		self.serializedCP=CommandSerializeProcedure(DataCenter)


		
	def interpretCommand(self, command):
		command=command.strip()
		if not self.isExecutable(command):
			return
		parts=self.analyzeCommand(command)
		#print parts
		cmdName=parts[0]
		cmdParams=parts[1:]
		#print cmdParams
		self.serializedCP.interpretCommand(cmdName,cmdParams)

		
	
def help2():
	r=""
	r+="    =======================================================================\n"
	r+="     Multi-Channel Diameter Protocol Redirector, version "+MCDPR_VER+"\n"
	r+="     Command: create, start, end, send, show, change, sleep, repeat, pause\n"
	r+="     Use \"quit\" \"exit\" \"q\" \":q\" to quit.\n"
	r+="     Use \"help <command-name>\" to get help.\n"
	r+="     Author: george.zhao@nokia.com\n"
	r+="    ======================================================================="
	r+=""
	return r
			
def main(argv):
	#dataCenter=DataCenter()
	#dmr=DiaMessageReader()
	#cer=dmr.createMessageFromXMLFile("cer.xml")
	
	#origHostName="zz-brand-simhss02.ims.mnc000.mcc460.3gppnetwork.org"
	#origRealm="ims.mnc000.mcc460.3gppnetwork.org"
	#dwa=dmr.createMessageFromXMLFile("dwa.xml")
	#connect to MME
	#mmeCer=generateCER(origHostName,origRealm)
	#mmeChn=DiaClient("192.168.168.173",3868,"TCP")
	#mmeChn.init(cer,"","",dwa)
	#mmeChn.connect() 
	print help2()
	#connect to HSS
	#hssCer=generateCER(origHostName,origRealm)
	#hssChn=DiaClient("192.168.165.169",3868,"TCP")
	#hssChn.init(cer,"","",dwa)
	#hssChn.connect()

	
	#dataCenter.addObject("mmeChn", mmeChn, "Connection", "Info for mme")
	#dataCenter.addObject("hssChn", hssChn, "Connection", "Info for hss")
	#print dataCenter.getObjectListByType("Connection")
	#print dataCenter.getObject("mmeChn")[0]
	#print dataCenter.getObject("hssChn")[0]
	#dataCenter.getObject("mmeChn")[0].disconnect()
	#dataCenter.getObject("hssChn")[0].disconnect()
	#mmeChn.disconnect()
	#hssChn.disconnect()
	#return 
	
	#start redirector to do redirector 
	#from mme to hss
	#dr1=DiaRedirector(mmeChn,hssChn)
	#dr1.enableReplaceDestHostName("shbhss01.fz.fj.node.ims.mnc000.mcc460.3gppnetwork.org")
	#dr1.enableReplaceDestRealm("ims.mnc000.mcc460.3gppnetwork.org")
	#dr1.disableMessageRedirect(319, False) # IDR answer will not be redirected.
	#dr1.start()
	#from hss to mme
	#dr2=DiaRedirector(hssChn,mmeChn)
	#dr2.start()	
	#main loop
	
	dc=DataCenter()
	ci=CommandInterpretor(dc)
	
	#add a null message in DC
	dmr=DiaMessageReader()
	nullMsg=dmr.createNullMessage(NULL_MSG_NAME)
	#print nullMsg
	dc.addObject(NULL_MSG_NAME, nullMsg, "message", "System Null Message, don't overwrite this object.")
	
	batchCmds=[]
	if len(argv)==2:
		batchFileName=argv[1]
		batchCmds=batch(batchFileName)
	
	while True:
		#print "cmd>",
		if len(batchCmds)!=0:
			cmd=batchCmds.pop(0)
			line=_PROMOT_+cmd
			print line
		else:
			cmd=raw_input(_PROMOT_)
			cmd=cmd.strip()
		if cmd=="quit" or cmd=="q" or cmd==":q" or cmd=="exit":
			print "    exiting..."
			cns=dc.getObjectListByType("connection")
			#print cns
			for item in cns:
				#print cns[item][0]
				print "    connection", item, "is exiting."
				cns[item][0].end()
			rds=dc.getObjectListByType("redirector")
			for item in rds:
				print "    redirector", item, "is exiting."
				rds[item][0].end()
			break;
#		elif cmd=="help":
#			print help2()
		else:
			ci.interpretCommand(cmd)
	
	
def batch(fileName):
	batchFileName=fileName
	ci=CommandInterpretor(None)
	#print "Does not support batch mode now."
	fp=open(batchFileName)
	cmds=[]
	for cmd in fp.readlines():
		cmd=cmd.strip()
		if not ci.isExecutable(cmd):
			continue
		cmds.append(cmd)
	return cmds
		
	
if __name__ == '__main__':
	if len(sys.argv)==1 or len(sys.argv)==2:
		main(sys.argv)	
	else:
		print "Usage: mcdpr-v2.py <batch-file-name>"