from xml.etree import ElementTree

intDict={"Integer32".lower():0, "Unsigned32".lower():1, "Enumerated".lower():2, "VendorId".lower():3, "AppId".lower():4,"Time".lower():5}
int64Dict={"Integer64".lower():0, "Unsigned64".lower():1}
stringDict={"OctetString".lower():0, "IPAddress".lower():1, "Time".lower():2, "UTF8String".lower():3, "DiameterIdentity".lower():4, "DiameterURI".lower():5, "IPFilterRule".lower():6,"QOSFilterRule".lower():7,"MIPRegistrationRequest".lower():8}
							

def readSpecAVPFromFile(filename, vendorid):
	doc=ElementTree.parse(filename)
	root=doc.getroot()
	avp=root.find("")
	avps=root.findall("avp")
	for a in avps:
		typeRoot=a.find("type")
		if typeRoot==None:
			#print "!!!!!!!!!!!"
			type="grp"
		else:
			type=typeRoot.attrib["type-name"]
		type=type.lower()
		avpName=a.attrib["name"]
		avpCode=a.attrib["code"]
		#print type=="grp"
		#print type.find("String")
		#print avpName, avpCode, type
		if intDict.has_key(type):
			t="int"
			print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
		elif int64Dict.has_key(type):
			t="int64"
			print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"			
		elif type=="grp":
			t="grp"
			print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
		elif stringDict.has_key(type):
			t="str"
			print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
		else:
			#print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			#print type
			t="str"
			print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
			
filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\nasreq.xml"
readSpecAVPFromFile(filename, 0)

filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\eap.xml"
readSpecAVPFromFile(filename, 0)

filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\mobileipv4.xml"
readSpecAVPFromFile(filename, 0)

filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\chargecontrol.xml"
readSpecAVPFromFile(filename, 0)

#filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\sunping.xml"
#readSpecAVPFromFile(filename, 42)


#filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\nokia.xml"
#readSpecAVPFromFile(filename, 94)

#filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\imscxdx.xml"
#readSpecAVPFromFile(filename, 10415)

#filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\TGPPGmb.xml"
#readSpecAVPFromFile(filename, 10415)

#filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\TGPPS9.xml"
#readSpecAVPFromFile(filename, 10415)

#filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\TGPPSh.xml"
#readSpecAVPFromFile(filename, 10415)

#filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\TGPPRx.xml"
#readSpecAVPFromFile(filename, 10415)

filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\sip.xml"
readSpecAVPFromFile(filename, 0)

#filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\gqpolicy.xml"
#readSpecAVPFromFile(filename, 10415)

#filename="D:\\work\\programming\\python\\MCDPRv1\\temp\\diameter\\etsie2e4.xml"
#readSpecAVPFromFile(filename, 13019)