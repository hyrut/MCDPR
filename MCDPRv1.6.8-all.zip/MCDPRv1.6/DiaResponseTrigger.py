from DiaMessage import *
from DiaAVP import *

SESSION_ID_AVP_CODE=263
SESSION_ID_AVP_VENDOR=0

SESSION_ID_AVP_PATH="0/263[0]"

class DiaResponseTrigger():
	#when connection got a message, Response Trigger will send back a message on targetConnection.
	def init(self, triggerName, msgMatch, targetConnection,resp):
		self.name=triggerName
		self.triggerType="Response Trigger"
		self.targetConnection=targetConnection
		self.responseMessage=resp
		self.msgMatch=msgMatch

	def findAVPValueFromMsg(self, msg, code, vendor, type, value):
		l=msg.getSameAVPCount(code)
		#print l
		i=0
		while i<l:
			r=msg.compareAVPValue(code, i, vendor, value)
			if r==True:
				return True
			i+=1
		return False
		
		
	def setMessageMatch(self, msgMatch):
		self.msgMatch=msgMatch

	def isMatched(self, msg):
		#print "===="
		#print msg.getCommandCode()==self.cmdCode
		#print msg.getApplicationId()==self.appId
		#print msg.isRequest()==self.requestFlag
		#print "===="
		return self.msgMatch.isMatched(msg)
		
	def execute(self, msg):
		ebeid=msg.getEBEID()
		hbhid=msg.getHBHID()
		rsp=self.responseMessage
		if rsp==None:
			#print "    Failed to get response message object."
			return True
		#print rsp
		rsp.setEBEID(ebeid)
		rsp.setHBHID(hbhid)
		#treat the session id avp
		dap=DiaAVPPath()
		dap.setPath(SESSION_ID_AVP_PATH)
		nullDap=DiaAVPPath()
		dap.setPath("")
		sessionIdAVP=msg.getAVPByPath(dap)
		rspSessionIdAVP=rsp.getAVPByPath(dap)
		#print "got", rsp, dap
		#print rspSessionIdAVP
		if not sessionIdAVP==None:
			if rspSessionIdAVP==None:
				#print "add"
				rsp.addAVPByPath(nullDap,sessionIdAVP)
				#add session-id avp in root
			else:
				rsp.replaceAVPByPath(dap,sessionIdAVP)
		#print "send rsp"
		self.targetConnection.send(rsp)
		return True
	
	"""
	def createFromXMLFile(self, name, xmlFileName, targetConnection, resp):
		if not os.path.exists(xmlFileName):
			return False
		try:
			doc=ElementTree.parse(xmlFileName)
			root=doc.getroot()
			commandRoot=root.find("Match/CommandCode")
			commandCode=int(commandRoot.text)
			appIdRoot=root.find("Match/ApplicationId")
			appId=int(appIdRoot.text)
			requestRoot=root.find("Match/Request")
			requestTxt=requestRoot.text
			request=(requestTxt.upper()=="TRUE")
			avpsRoot=root.findall("Match/AVP")
			#print len(avpsRoot)
			avps=[]
			for item in avpsRoot:
				avp=DiaAVP.readAVPFromXmlRoot(item)
				#print "type:",avp.getType()
				avps.append(avp)
			self.init(name, commandCode, appId, request, avps, targetConnection, resp)
		except Exception as e:
			#print "error:"
			print e
			return False
		return True
	"""
	
	def getInfo(self):
		s="\n"
		s+="        messageMatch object is "+ self.msgMatch.getName()+"\n"
		s+="        Connection object is "+ self.targetConnection.getName()+"\n"
		s+="        Resp. message object is "+self.responseMessage.getName()+"\n"
		return s
	
	def getName(self):
		return self.name