from xml.etree import ElementTree
import sys

intDict={"Integer32":0, "Unsigned32":1, "Enumerated":2, "VendorId":3, "AppId":4,"Time":5}
int64Dict={"Integer64":0, "Unsigned64":1}
stringDict={"OctetString":0, "IPAddress":1, "Time":2, "UTF8String":3, "DiameterIdentity":4, "DiameterURI":5, "IPFilterRule":6,"QOSFilterRule":7,"MIPRegistrationRequest":8}
vendorDict={"Base Diameter":0, "HP":11, "Sun":42, "Merit":61, "Nokia":94, "NokiaSiemensNetworks":28458, "Ericsson":193, "USR":429, "ALU":637, "Lucent":1751, "Huawei":2011, "Deutsche_Telekom_AG":2937, "TGPP2":5535, "Cisco":5771, "SKT":5806, "Starent":8164, "TGPP":10415, "Vodafone":12645, "VerizonWireless":12951, "ETSI":13019, "Tango":13421, "ChinaTelecom":81000, "Acision":3830}

commentDict={}

#vendorDict= {"Nokia":94, "NokiaSiemensNetworks":28458, "TGPP":10415}

avpDict={}

def printAVPDict(avpDict):
	print "{"
	vendornum=0
	for vendor in avpDict:
		s=str(vendor)+":{"
		print s
		codenum=0
		for avpcode in avpDict[vendor]:
			s="\t"+str(avpcode)+":{'name':'"+avpDict[vendor][avpcode]['name']+"', 'type':'"+avpDict[vendor][avpcode]['type']+"'}"
			codenum+=1
			if codenum<len(avpDict[vendor]):
				s+=","
			print s
		print "}",
		vendornum+=1
		if vendornum<len(avpDict):
			print ","
	print "}"

def printTab(tab):
	i=0
	while i<tab:
		print " ",
		i+=1
		
def getItemInfo(item):
		a=item
		typeRoot=a.find("type")
		if typeRoot==None:
			type="grp"
		else:
			type=typeRoot.attrib["type-name"]
		avpName=a.attrib["name"]
		avpCode=int(a.attrib["code"])
		avpVendorId=0
		if not a.attrib.has_key("vendor-id"):
			avpVendorId=0
		else:
			avpVendorText=a.attrib["vendor-id"]
			#print avpVendorText
			if vendorDict.has_key(avpVendorText):
				avpVendorId=vendorDict[avpVendorText]
			else:
				avpVendorId=-1
				#print "Unknown avpVendor "+avpVendorText
		#print avpName, avpCode, type
		if intDict.has_key(type):
			t="int"
			#print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
		elif int64Dict.has_key(type):
			t="int64"
			#print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"			
		elif type=="grp":
			t="grp"
			#print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
		elif stringDict.has_key(type):
			t="str"
			#print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"
		else:
			#print "Unknown type"
			#print type
			t="str"
			#print str(avpCode)+":{'name': \'"+avpName+"\',\'type\':\'"+t+"\'},"		
		return [avpCode, avpName, avpVendorId, t]
		
def printItem(item):
	if item.tag=="avp":
		r=getItemInfo(item)
		#print r
		avpCode=r[0]
		avpName=r[1]
		avpVendorId=r[2]
		avpType=r[3]
		if avpVendorId==-1:
			return 
		if not avpDict.has_key(avpVendorId):
			avpDict[avpVendorId]={}
		avpDict[avpVendorId][avpCode]={"name":avpName, "type":avpType}
	
def printItems(root, tab):
	printTab(tab)
	printItem(root)
	items=root.findall("*")
	#print "len", len(items)
	if len(items)==0:
		#print root.tag
		return 
	for item in items:
		printItems(item,tab)
		
def printAvpDictInXMLFormat(avpDict):
	print "<AvpDict>"
	for vendor in avpDict:
		s="<Vendor vendorcode=\""+str(vendor)+"\">"
		print s
		for code in avpDict[vendor]:
			s="\t<AVP name=\""+avpDict[vendor][code]['name']+"\" code=\""+str(code)+"\" type=\""+avpDict[vendor][code]['type']+"\"></AVP>"
			print s
		s="</Vendor>"
		print s
	print "</AvpDict>"
	
def printAvpDictInXMLFormat2(avpDict):
	print "<AvpDict>"
	vendorlist=[]
	for vendor in avpDict:
		i=0
		while i<len(vendorlist):
			if vendor>vendorlist[i]:
				i+=1
				continue
			break
		vendorlist.insert(i,vendor)

	for vendor in vendorlist:
		comment="<!--vendor="+str(vendor)+", "+commentDict[vendor]+"-->"
		print comment
		s="<Vendor vendorcode=\""+str(vendor)+"\" vendorname=\""+commentDict[vendor]+"\">"
		print s
		codelist=[]
		for code in avpDict[vendor]:
			i=0
			while i<len(codelist):
				if int(code)>codelist[i]:
					i+=1
					continue
				break
			codelist.insert(i,int(code))
		i=0
		while i<len(avpDict[vendor]):
			code=codelist[i]
			s="\t<AVP name=\""+avpDict[vendor][code]['name']+"\" code=\""+str(code)+"\" type=\""+avpDict[vendor][code]['type']+"\"></AVP>"
			print s
			i+=1
		s="</Vendor>"
		print s
	print "</AvpDict>"
	
def initCommentDict():
	for vendor in vendorDict:
		commentDict[vendorDict[vendor]]=vendor

def main(filename):
	file=filename
	doc=ElementTree.parse(file)
	root=doc.getroot()
	printItems(root,0)
	
if __name__=="__main__":
	initCommentDict()
	main("diameter\\AlcatelLucent.xml")
	main("diameter\\chargecontrol.xml")
	main("diameter\\ChinaTelecom.xml")
	main("diameter\\Cisco.xml")
	main("diameter\\Custom.xml")
	main("diameter\\dictionary.xml")
	main("diameter\\eap.xml")
	main("diameter\\Ericsson.xml")
	main("diameter\\etsie2e4.xml")
	main("diameter\\gqpolicy.xml")
	main("diameter\\imscxdx.xml")
	main("diameter\\mobileipv4.xml")
	main("diameter\\mobileipv6.xml")
	main("diameter\\nasreq.xml")
	main("diameter\\Nokia.xml")
	main("diameter\\NokiaSiemensNetworks.xml")
	main("diameter\\sip.xml")
	main("diameter\\SKT.xml")
	main("diameter\\Starent.xml")
	main("diameter\\sunping.xml")
	main("diameter\\TGPPGmb.xml")
	main("diameter\\TGPPRx.xml")
	main("diameter\\TGPPS9.xml")
	main("diameter\\TGPPSh.xml")
	main("diameter\\VerizonWireless.xml")
	main("diameter\\Vodafone.xml")
	printAvpDictInXMLFormat2(avpDict)