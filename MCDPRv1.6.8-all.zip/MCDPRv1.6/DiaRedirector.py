from DiaMessage import DiaMessage, DiaAVPPath
from DiaConnection import DiaConnection
from DiaAVP import *
from DiaAVPDict import *
from DiaRedirectorMM import *

import threading, thread

DESTHOSTNAME_AVPPATH="0/293[0]"
DESTREALMNAME_AVPPATH="0/283[0]"

class DiaRedirector():
	def __init__(self, chn1, chn2):
		self.chn1=chn1
		self.chn2=chn2
		self.quit=True
		self.quitDone=True
		self.destHostName=""
		self.destRealm=""	
		self.disableMessages=[]
		self.entryPointMM=[]
		self.exitPointMM=[]
	
	def enableReplaceDestHostName(self, destHostName):
		self.destHostName=destHostName
	
	def enableReplaceDestRealm(self, destRealm):
		self.destRealm=destRealm

	def disableReplaceDestHostName(self, destHostName):
		self.destHostName=""
	
	def disableReplaceDestRealm(self, destRealm):
		self.destRealm=""		
	
	
	def loop(self):
		#print "loop"
		self.quit=False
		self.quitDone=False
		while not self.quit:
			#print "DR:", self.quit, self.quitDone
			msgs=self.chn1.read()
			if len(msgs)!=0:
				i=0
				for msg in msgs:
					#msg.printDebugInfo()
					self.executeMM(self.entryPointMM, msg)
					#msg.printDebugInfo()
					if self.destHostName!="":
						destHostAVP=msg.getAVPByPath(DESTHOSTNAME_AVPPATH)
						destHostAVP.replaceAVPValue(self.destHostName)
					if self.destRealm!="":
						destRealmAVP=msg.getAVPByPath(DESTREALMNAME_AVPPATH)
						destRealmAVP.replaceAVPValue(self.destRealm)
					if self.needRedirect(msg):
						self.executeMM(self.exitPointMM, msg)
						self.chn2.send(msg)
						i+=1
					#print i, "messages was sent."
		self.quitDone=True
	
	def start(self):
		self.thread=threading.Thread(target=self.loop,args=())
		self.thread.start()
	
	def end(self):
		self.quit=True
		while not self.quitDone:
			pass
	
	def executeMM(self, mmItemList, msg):
		for mmItem in mmItemList:
			msgMatch=mmItem[0]
			mm=mmItem[1]
			if msgMatch.isMatched(msg):
				#print "match!"
				mm.manipulate(msg)
		
	def needRedirect(self, msg):
		try:
			r=True
			for msgMatch in self.disableMessages:
				if msgMatch.isMatched(msg):
					return False
			#print "result:", r
			return r
		except Exception as e:
			#print "Error:", e
			return True
		
	def disableMessageRedirect(self, msgMatch):
		self.disableMessages.append(msgMatch)
		
	def removeDisableMessageRedirectRule(self, index):
		if index>=len(self.disableMessages):
			return False
		self.disableMessages.pop(index)
		return True
		
	def addEntryPointRedirectorMM(self, msgMatch, mm):
		#add entry point redirector message manipulation, DiaRedirectorMM
		#print "ADD!"
		self.entryPointMM.append([msgMatch,mm])
		
	def removeEntryPointRedirectorMM(self, index):
		if index>=len(self.entryPointMM):
			return False
		self.entryPointMM.pop(index)
		return True		
		
	def addExitPointRedirectorMM(self, msgMatch,mm):
		#add entry point redirector message manipulation, DiaRedirectorMM
		self.exitPointMM.append([msgMatch, mm])
		
	def removeExitPointRedirectorMM(self, index):
		if index>=len(self.exitPointMM):
			return False
		self.exitPointMM.pop(index)
		return True		
		
	def getInfo(self):
		if self.quitDone:
			r="Not running"
		else:
			r="Running"
		r+="\n"
		if self.destHostName!="":
			r+="      ReplaceDestHostName is enabled:"+self.destHostName+"\n"
		if self.destRealm!="":
			r+="      ReplaceDestRealm is enabled:"+self.destRealm+"\n"
		i=0
		for item in self.disableMessages:
			r+="      msgRestrictionRule index:"+str(i)+"\n"
			r+="        messageMatch object name:"+str(item.getName())+"\n"
			i+=1
		i=0
		for item in self.entryPointMM:
			r+="      entryPoint redirectorMM index:"+str(i)+"\n"
			r+="        msgMatch object name:"+str(item[0].getName())+"\n"
			r+="        redirectorMM object name:"+str(item[1].getName())+"\n"
			i+=1
		i=0
		for item in self.exitPointMM:
			r+="      exitPoint redirectorMM index:"+str(i)+"\n"
			r+="        msgMatch object name:"+str(item[0].getName())+"\n"
			r+="        redirectorMM object name:"+str(item[1].getName())+"\n"
			i+=1
		return r